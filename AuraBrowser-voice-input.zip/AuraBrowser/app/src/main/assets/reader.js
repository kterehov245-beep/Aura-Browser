(function () {
  function esc(s) {
    return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }
  var candidates = document.querySelectorAll("article, main, [role=main], .post, .article, .content, #content, body");
  var best = null;
  var bestLen = 0;
  for (var i = 0; i < candidates.length; i++) {
    var ps = candidates[i].querySelectorAll("p");
    var len = 0;
    for (var j = 0; j < ps.length; j++) len += (ps[j].innerText || "").length;
    if (len > bestLen) { bestLen = len; best = candidates[i]; }
  }
  if (!best || bestLen < 300) return "no";

  var out = "";
  var nodes = best.querySelectorAll("h1, h2, h3, p, li, blockquote, img");
  for (var k = 0; k < nodes.length; k++) {
    var n = nodes[k];
    var tag = n.tagName.toLowerCase();
    if (tag === "img") {
      if (n.naturalWidth >= 250 && n.src) out += '<img src="' + n.src.replace(/"/g, "") + '">';
      continue;
    }
    var t = (n.innerText || "").trim();
    if (!t) continue;
    if (tag === "li") out += "<p>\u2022 " + esc(t) + "</p>";
    else out += "<" + tag + ">" + esc(t) + "</" + tag + ">";
  }

  var night = document.getElementById("aura-night");
  if (night) night.remove();

  var title = esc(document.title || "");
  document.body.innerHTML = '<div class="aura-reader"><div class="tag">РЕЖИМ ЧТЕНИЯ</div><h1>' + title + "</h1>" + out + "</div>";
  var st = document.createElement("style");
  st.textContent = "html,body{background:#12131a!important;margin:0!important}" +
    "body{color:#d8dbe9!important;font-family:Georgia,serif!important}" +
    ".aura-reader{max-width:680px;margin:0 auto;padding:22px 18px 60px;font-size:18px;line-height:1.7}" +
    ".aura-reader h1{font-size:26px;line-height:1.3;color:#fff}" +
    ".aura-reader h2,.aura-reader h3{color:#fff;margin-top:1.4em}" +
    ".aura-reader p,.aura-reader blockquote{margin:0 0 1em}" +
    ".aura-reader blockquote{border-left:3px solid #6366f1;padding-left:12px;color:#aeb3c8}" +
    ".aura-reader img{max-width:100%;height:auto;border-radius:10px;margin:8px 0}" +
    ".aura-reader .tag{font-size:12px;letter-spacing:1px;color:#8f93ff;margin-bottom:8px}";
  document.head.appendChild(st);
  window.scrollTo(0, 0);
  return "ok";
})()
