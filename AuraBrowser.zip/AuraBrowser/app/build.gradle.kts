plugins {
    id("com.android.application")
}

android {
    namespace = "com.aura.browser"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.aura.browser"
        minSdk = 24
        targetSdk = 34
        versionCode = 2
        versionName = "1.1"
    }

    // Постоянный ключ подписи: новые версии устанавливаются поверх старых
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
