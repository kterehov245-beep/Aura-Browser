package com.aura.browser;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    // ---- Настройки, которые можно менять ----
    private static final String SEARCH = "https://duckduckgo.com/?q="; // поисковик (можно заменить)
    private static final String AI_URL = "https://claude.ai"; // кнопка ✨ и плитка "AI Chat"
    private static final String[] SPACE_KEYS = {"home", "work", "study", "projects"};
    private static final String[] SPACE_NAMES = {"✨ Главная", "💼 Работа", "📚 Учеба", "🚀 Проекты"};

    // ---- Цвета ----
    private static final int BG = 0xFF0E0F14;
    private static final int TOP_BAR = 0xFF1B1B1B;
    private static final int ACCENT = 0xFF6366F1;

    private static final String HOME_PAGE = "file:///android_asset/home.html";
    private static final String ASSET_PREFIX = "file:///android_asset/";
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    private WebView web;
    private EditText input;
    private ProgressBar progress;
    private final TextView[] chipViews = new TextView[SPACE_KEYS.length];
    private int currentSpace = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(TOP_BAR);
        getWindow().setNavigationBarColor(BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgressTintList(ColorStateList.valueOf(ACCENT));

        web = new WebView(this);
        web.setBackgroundColor(BG);
        setupWebView();

        View line = new View(this);
        line.setBackgroundColor(0xFF2A2C3A);

        root.addView(buildTopBar(), new LinearLayout.LayoutParams(MATCH, dp(56)));
        root.addView(buildChips(), new LinearLayout.LayoutParams(MATCH, WRAP));
        root.addView(line, new LinearLayout.LayoutParams(MATCH, dp(1)));
        root.addView(progress, new LinearLayout.LayoutParams(MATCH, dp(3)));
        root.addView(web, new LinearLayout.LayoutParams(MATCH, 0, 1f));
        root.addView(buildSearchBar(), new LinearLayout.LayoutParams(MATCH, WRAP));
        setContentView(root);

        Uri data = getIntent().getData();
        if (data != null) {
            web.loadUrl(data.toString()); // ссылка из другого приложения
        } else {
            openSpace(0);
        }
    }

    // ---------- Верхняя панель: название и звезда ----------
    private View buildTopBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(TOP_BAR);
        bar.setPadding(dp(16), 0, dp(12), 0);

        TextView title = new TextView(this);
        title.setText("Aura browser");
        title.setTextColor(Color.WHITE);
        title.setTextSize(22);
        title.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        bar.addView(title, new LinearLayout.LayoutParams(0, WRAP, 1f));

        TextView star = new TextView(this);
        star.setText("★");
        star.setTextColor(0xFF6BBF3B);
        star.setTextSize(34);
        star.setPadding(dp(8), 0, dp(8), 0);
        star.setOnClickListener(v -> showMenu());
        bar.addView(star, new LinearLayout.LayoutParams(WRAP, WRAP));
        return bar;
    }

    // ---------- Вкладки-пространства: Главная, Работа, Учеба, Проекты ----------
    private View buildChips() {
        HorizontalScrollView scroll = new HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(false);
        scroll.setBackgroundColor(0xFF121420);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(dp(16), dp(12), dp(6), dp(12));

        for (int i = 0; i < SPACE_KEYS.length; i++) {
            final int index = i;
            TextView chip = new TextView(this);
            chip.setText(SPACE_NAMES[i]);
            chip.setTextSize(15);
            chip.setGravity(Gravity.CENTER);
            chip.setPadding(dp(18), dp(9), dp(18), dp(9));
            chip.setOnClickListener(v -> openSpace(index));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(WRAP, WRAP);
            lp.setMargins(0, 0, dp(10), 0);
            row.addView(chip, lp);
            chipViews[i] = chip;
        }
        scroll.addView(row);
        selectSpace(0);
        return scroll;
    }

    private void selectSpace(int index) {
        currentSpace = index;
        for (int i = 0; i < chipViews.length; i++) {
            boolean on = (i == index);
            chipViews[i].setBackground(on
                    ? rounded(ACCENT, 0, 22)
                    : rounded(0xFF1B1D2B, 0xFF3A3C50, 22));
            chipViews[i].setTextColor(on ? Color.WHITE : 0xFFC9CDE0);
        }
    }

    private void openSpace(int index) {
        selectSpace(index);
        web.loadUrl(HOME_PAGE + "#" + SPACE_KEYS[index]);
    }

    // ---------- Нижняя строка поиска ----------
    private View buildSearchBar() {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setBackgroundColor(BG);
        wrap.setPadding(dp(16), dp(10), dp(16), dp(12));

        LinearLayout pill = new LinearLayout(this);
        pill.setOrientation(LinearLayout.HORIZONTAL);
        pill.setGravity(Gravity.CENTER_VERTICAL);
        pill.setBackground(rounded(0xFF15161F, 0xFF2D2F40, 26));
        pill.setPadding(dp(8), 0, dp(8), 0);

        pill.addView(icon("🏠", v -> openSpace(currentSpace)));
        pill.addView(icon("✨", v -> web.loadUrl(AI_URL)));

        input = new EditText(this);
        input.setBackground(null);
        input.setSingleLine(true);
        input.setTextColor(Color.WHITE);
        input.setHintTextColor(0xFF7A8096);
        input.setHint("Поиск или адрес сайта");
        input.setTextSize(16);
        input.setSelectAllOnFocus(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        input.setImeOptions(EditorInfo.IME_ACTION_GO);
        input.setOnEditorActionListener((v, actionId, event) -> {
            submit();
            return true;
        });
        pill.addView(input, new LinearLayout.LayoutParams(0, MATCH, 1f));

        pill.addView(icon("🔍", v -> submit()));

        wrap.addView(pill, new LinearLayout.LayoutParams(MATCH, dp(52)));
        return wrap;
    }

    private TextView icon(String symbol, View.OnClickListener listener) {
        TextView t = new TextView(this);
        t.setText(symbol);
        t.setTextSize(20);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(10), 0, dp(10), 0);
        t.setOnClickListener(listener);
        t.setLayoutParams(new LinearLayout.LayoutParams(WRAP, MATCH));
        return t;
    }

    private void submit() {
        go(input.getText().toString());
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(input.getWindowToken(), 0);
        input.clearFocus();
        web.requestFocus();
    }

    // Адрес -> открыть сайт, обычный текст -> поиск
    private void go(String raw) {
        String text = raw.trim();
        if (text.isEmpty()) return;
        String url;
        if (text.startsWith("http://") || text.startsWith("https://")) {
            url = text;
        } else if (text.contains(".") && !text.contains(" ")) {
            url = "https://" + text;
        } else {
            url = SEARCH + Uri.encode(text);
        }
        web.loadUrl(url);
    }

    // ---------- Страница ----------
    private void setupWebView() {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        // Убираем из User-Agent пометку WebView, чтобы сайты считали нас обычным браузером
        s.setUserAgentString(s.getUserAgentString().replace("; wv", "").replace("Version/4.0 ", ""));
        s.setDomStorageEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if ("http".equals(scheme) || "https".equals(scheme)) {
                    return false;
                }
                if (uri.toString().startsWith(ASSET_PREFIX)) {
                    return false; // наша стартовая страница
                }
                if ("aura".equals(scheme)) {
                    if ("search".equals(uri.getHost())) {
                        String q = uri.getQueryParameter("q"); // плитки на стартовой странице
                        view.loadUrl(SEARCH + Uri.encode(q == null ? "" : q));
                    } else {
                        view.loadUrl(AI_URL); // плитка "AI Chat"
                    }
                    return true;
                }
                try { // mailto:, tel: и т.п. отдаём другим приложениям
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (Exception ignored) { }
                return true;
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                input.setText(url.startsWith(ASSET_PREFIX) ? "" : url);
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progress.setProgress(newProgress);
                progress.setVisibility(newProgress < 100 ? View.VISIBLE : View.INVISIBLE);
            }
        });

        web.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            try {
                String name = URLUtil.guessFileName(url, contentDisposition, mimeType);
                DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
                req.setMimeType(mimeType);
                req.addRequestHeader("User-Agent", userAgent);
                String cookie = CookieManager.getInstance().getCookie(url);
                if (cookie != null) req.addRequestHeader("Cookie", cookie);
                req.setTitle(name);
                req.setNotificationVisibility(
                        DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
                ((DownloadManager) getSystemService(DOWNLOAD_SERVICE)).enqueue(req);
                toast("Скачивание: " + name);
            } catch (Exception e) {
                toast("Не удалось скачать файл");
            }
        });
    }

    // ---------- Звезда: меню и избранное ----------
    private void showMenu() {
        final List<String[]> favs = loadFavs();
        List<String> labels = new ArrayList<>();
        labels.add("＋ Добавить эту страницу в избранное");
        labels.add("↻ Обновить страницу");
        labels.add("🗑 Очистить избранное");
        for (String[] f : favs) labels.add("★ " + f[0]);

        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("Aura browser")
                .setItems(labels.toArray(new String[0]), (dialog, which) -> {
                    if (which == 0) {
                        addFav(favs);
                    } else if (which == 1) {
                        web.reload();
                    } else if (which == 2) {
                        saveFavs(new ArrayList<String[]>());
                        toast("Избранное очищено");
                    } else {
                        web.loadUrl(favs.get(which - 3)[1]);
                    }
                })
                .show();
    }

    private void addFav(List<String[]> favs) {
        String url = web.getUrl();
        if (url == null || url.startsWith(ASSET_PREFIX)) {
            toast("Сначала откройте сайт");
            return;
        }
        String title = web.getTitle();
        if (title == null || title.trim().isEmpty()) title = url;
        title = title.replace('\t', ' ').replace('\n', ' ').trim();
        for (String[] f : favs) {
            if (f[1].equals(url)) {
                toast("Уже в избранном");
                return;
            }
        }
        favs.add(new String[]{title, url});
        saveFavs(favs);
        toast("Добавлено в избранное ★");
    }

    private List<String[]> loadFavs() {
        List<String[]> list = new ArrayList<>();
        String raw = getSharedPreferences("aura", MODE_PRIVATE).getString("favs", "");
        for (String line : raw.split("\n")) {
            String[] parts = line.split("\t", 2);
            if (parts.length == 2 && !parts[1].isEmpty()) list.add(parts);
        }
        return list;
    }

    private void saveFavs(List<String[]> list) {
        StringBuilder sb = new StringBuilder();
        for (String[] f : list) sb.append(f[0]).append('\t').append(f[1]).append('\n');
        getSharedPreferences("aura", MODE_PRIVATE).edit().putString("favs", sb.toString()).apply();
    }

    // ---------- Мелочи ----------
    private GradientDrawable rounded(int fill, int stroke, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radiusDp));
        if (stroke != 0) d.setStroke(dp(1), stroke);
        return d;
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
    }
}
