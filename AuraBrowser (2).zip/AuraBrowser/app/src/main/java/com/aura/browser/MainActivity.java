package com.aura.browser;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    // ---- Настройки, которые можно менять ----
    // Поисковики: название и начало адреса (в конец добавляется запрос).
    // Хотите другой поисковик - добавьте строку в оба списка.
    private static final String[] ENGINE_NAMES = {"DuckDuckGo", "Brave", "Яндекс", "Bing", "Google"};
    private static final String[] ENGINE_URLS = {
            "https://duckduckgo.com/?q=",
            "https://search.brave.com/search?q=",
            "https://yandex.ru/search/?text=",
            "https://www.bing.com/search?q=",
            "https://www.google.com/search?q="
    };
    private static final String AI_URL = "https://alice.yandex.ru"; // кнопка ✨ и плитка "AI Chat"

    // Ответ нейросети над результатами поиска (Яндекс AI Studio, модель Alice AI LLM).
    // Ключ и идентификатор каталога вводятся в самом приложении: звезда -> "Подключить Алису".
    private static final String AI_API_URL = "https://ai.api.cloud.yandex.net/v1/responses";
    private static final String AI_MODEL = "aliceai-llm"; // дешевле и быстрее: "aliceai-llm-flash"
    private static final String AI_PROMPT =
            "Ты помощник в браузере. Ответь на запрос пользователя понятно и по делу, "
            + "на языке запроса, без вступлений и лишних слов. "
            + "Если это вопрос «как сделать», дай короткий пошаговый ответ. Запрос: ";
    private static final String[] SPACE_KEYS = {"home", "work", "study", "projects"};
    private static final String[] SPACE_NAMES = {"✨ Главная", "💼 Работа", "📚 Учеба", "🚀 Проекты"};

    // ---- Цвета ----
    private static final int BG = 0xFF0E0F14;
    private static final int TOP_BAR = 0xFF1B1B1B;
    private static final int ACCENT = 0xFF6366F1;

    private static final String HOME_PAGE = "file:///android_asset/home.html";
    private static final String SEARCH_PAGE = "file:///android_asset/search.html"; // страница "Карточка Aura"
    private static final String ASSET_PREFIX = "file:///android_asset/";
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    private WebView web;
    private EditText input;
    private ProgressBar progress;
    private final TextView[] chipViews = new TextView[SPACE_KEYS.length];
    private int currentSpace = 0;
    private int engine = 0;          // выбранный поисковик
    private boolean aiMode = true;   // показывать ответ Алисы перед поиском
    private int aiRequestId = 0;     // номер последнего вопроса к Алисе
    private boolean aiDone = false;
    private String aiAnswer = "";
    private String aiError = "";
    private boolean warnedNoKey = false;
    private final TextView[] engineChips = new TextView[ENGINE_NAMES.length];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SharedPreferences prefs = getSharedPreferences("aura", MODE_PRIVATE);
        engine = prefs.getInt("engine", 0);
        if (engine < 0 || engine >= ENGINE_NAMES.length) engine = 0;
        aiMode = prefs.getBoolean("ai_on", true);

        getWindow().setStatusBarColor(TOP_BAR);
        getWindow().setNavigationBarColor(BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgressTintList(ColorStateList.valueOf(ACCENT));

        web = new WebView(this);
        web.setBackgroundColor(BG);
        setupWebView();

        View line = new View(this);
        line.setBackgroundColor(0xFF2A2C3A);

        root.addView(buildTopBar(), new LinearLayout.LayoutParams(MATCH, dp(56)));
        root.addView(buildChips(), new LinearLayout.LayoutParams(MATCH, WRAP));
        root.addView(line, new LinearLayout.LayoutParams(MATCH, dp(1)));
        root.addView(progress, new LinearLayout.LayoutParams(MATCH, dp(3)));
        root.addView(web, new LinearLayout.LayoutParams(MATCH, 0, 1f));
        root.addView(buildSearchBar(), new LinearLayout.LayoutParams(MATCH, WRAP));
        setContentView(root);

        Uri data = getIntent().getData();
        if (data != null) {
            web.loadUrl(data.toString()); // ссылка из другого приложения
        } else {
            openSpace(0);
        }
    }

    // ---------- Верхняя панель: название и звезда ----------
    private View buildTopBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(TOP_BAR);
        bar.setPadding(dp(16), 0, dp(12), 0);

        TextView title = new TextView(this);
        title.setText("Aura browser");
        title.setTextColor(Color.WHITE);
        title.setTextSize(22);
        title.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        bar.addView(title, new LinearLayout.LayoutParams(0, WRAP, 1f));

        TextView star = new TextView(this);
        star.setText("★");
        star.setTextColor(0xFF6BBF3B);
        star.setTextSize(34);
        star.setPadding(dp(8), 0, dp(8), 0);
        star.setOnClickListener(v -> showMenu());
        bar.addView(star, new LinearLayout.LayoutParams(WRAP, WRAP));
        return bar;
    }

    // ---------- Вкладки-пространства: Главная, Работа, Учеба, Проекты ----------
    private View buildChips() {
        HorizontalScrollView scroll = new HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(false);
        scroll.setBackgroundColor(0xFF121420);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(dp(16), dp(12), dp(6), dp(12));

        for (int i = 0; i < SPACE_KEYS.length; i++) {
            final int index = i;
            TextView chip = new TextView(this);
            chip.setText(SPACE_NAMES[i]);
            chip.setTextSize(15);
            chip.setGravity(Gravity.CENTER);
            chip.setPadding(dp(18), dp(9), dp(18), dp(9));
            chip.setOnClickListener(v -> openSpace(index));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(WRAP, WRAP);
            lp.setMargins(0, 0, dp(10), 0);
            row.addView(chip, lp);
            chipViews[i] = chip;
        }
        scroll.addView(row);
        selectSpace(0);
        return scroll;
    }

    private void selectSpace(int index) {
        currentSpace = index;
        for (int i = 0; i < chipViews.length; i++) {
            boolean on = (i == index);
            chipViews[i].setBackground(on
                    ? rounded(ACCENT, 0, 22)
                    : rounded(0xFF1B1D2B, 0xFF3A3C50, 22));
            chipViews[i].setTextColor(on ? Color.WHITE : 0xFFC9CDE0);
        }
    }

    private void openSpace(int index) {
        selectSpace(index);
        web.loadUrl(HOME_PAGE + "#" + SPACE_KEYS[index]);
    }

    // ---------- Нижняя строка поиска ----------
    private View buildSearchBar() {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setBackgroundColor(BG);
        wrap.setPadding(dp(16), dp(10), dp(16), dp(12));

        // Выбор поисковика: появляется, когда вы начинаете вводить запрос
        final HorizontalScrollView engineScroll = new HorizontalScrollView(this);
        engineScroll.setHorizontalScrollBarEnabled(false);
        engineScroll.setVisibility(View.GONE);
        LinearLayout engineRow = new LinearLayout(this);
        engineRow.setOrientation(LinearLayout.HORIZONTAL);
        engineRow.setPadding(0, 0, 0, dp(10));
        for (int i = 0; i < ENGINE_NAMES.length; i++) {
            final int index = i;
            TextView chip = new TextView(this);
            chip.setText(ENGINE_NAMES[i]);
            chip.setTextSize(13);
            chip.setGravity(Gravity.CENTER);
            chip.setPadding(dp(14), dp(7), dp(14), dp(7));
            chip.setOnClickListener(v -> setEngine(index));
            LinearLayout.LayoutParams chipLp = new LinearLayout.LayoutParams(WRAP, WRAP);
            chipLp.setMargins(0, 0, dp(8), 0);
            engineRow.addView(chip, chipLp);
            engineChips[i] = chip;
        }
        engineScroll.addView(engineRow);
        wrap.addView(engineScroll, new LinearLayout.LayoutParams(MATCH, WRAP));

        LinearLayout pill = new LinearLayout(this);
        pill.setOrientation(LinearLayout.HORIZONTAL);
        pill.setGravity(Gravity.CENTER_VERTICAL);
        pill.setBackground(rounded(0xFF15161F, 0xFF2D2F40, 26));
        pill.setPadding(dp(8), 0, dp(8), 0);

        pill.addView(icon("🏠", v -> openSpace(currentSpace)));
        pill.addView(icon("✨", v -> web.loadUrl(AI_URL)));

        input = new EditText(this);
        input.setBackground(null);
        input.setSingleLine(true);
        input.setTextColor(Color.WHITE);
        input.setHintTextColor(0xFF7A8096);
        input.setHint("Поиск или адрес сайта");
        input.setTextSize(16);
        input.setSelectAllOnFocus(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        input.setImeOptions(EditorInfo.IME_ACTION_GO);
        input.setOnFocusChangeListener((v, hasFocus) ->
                engineScroll.setVisibility(hasFocus ? View.VISIBLE : View.GONE));
        input.setOnEditorActionListener((v, actionId, event) -> {
            submit();
            return true;
        });
        pill.addView(input, new LinearLayout.LayoutParams(0, MATCH, 1f));

        pill.addView(icon("🔍", v -> submit()));

        wrap.addView(pill, new LinearLayout.LayoutParams(MATCH, dp(52)));
        refreshEngineUI();
        return wrap;
    }

    private TextView icon(String symbol, View.OnClickListener listener) {
        TextView t = new TextView(this);
        t.setText(symbol);
        t.setTextSize(20);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(10), 0, dp(10), 0);
        t.setOnClickListener(listener);
        t.setLayoutParams(new LinearLayout.LayoutParams(WRAP, MATCH));
        return t;
    }

    private void submit() {
        go(input.getText().toString());
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(input.getWindowToken(), 0);
        input.clearFocus();
        web.requestFocus();
    }

    // Адрес -> открыть сайт, обычный текст -> поиск
    private void go(String raw) {
        String text = raw.trim();
        if (text.isEmpty()) return;
        if (text.startsWith("http://") || text.startsWith("https://")) {
            web.loadUrl(text);
        } else if (text.contains(".") && !text.contains(" ")) {
            web.loadUrl("https://" + text);
        } else {
            searchQuery(text);
        }
    }

    private String searchUrl(String query) {
        return ENGINE_URLS[engine] + Uri.encode(query);
    }

    // Поиск: если Алиса подключена - сначала страница Aura с ответом нейросети,
    // иначе сразу выбранный поисковик
    private void searchQuery(String text) {
        SharedPreferences prefs = getSharedPreferences("aura", MODE_PRIVATE);
        String key = prefs.getString("ai_key", "");
        String folder = prefs.getString("ai_folder", "");
        if (!aiMode) {
            web.loadUrl(searchUrl(text));
            return;
        }
        if (key.isEmpty() || folder.isEmpty()) {
            if (!warnedNoKey) {
                warnedNoKey = true;
                Toast.makeText(this, "Чтобы получать ответы Алисы, подключите её: звезда ★ → «Подключить Алису»",
                        Toast.LENGTH_LONG).show();
            }
            web.loadUrl(searchUrl(text));
            return;
        }
        aiRequestId++;
        final int id = aiRequestId;
        aiDone = false;
        aiAnswer = "";
        aiError = "";
        try {
            JSONArray list = new JSONArray();
            for (int i = 0; i < ENGINE_NAMES.length; i++) {
                list.put(new JSONArray().put(ENGINE_NAMES[i]).put(ENGINE_URLS[i]));
            }
            JSONObject data = new JSONObject();
            data.put("q", text);
            data.put("e", engine);
            data.put("id", id);
            data.put("engines", list);
            web.loadUrl(SEARCH_PAGE + "#" + Uri.encode(data.toString()));
        } catch (JSONException ex) {
            web.loadUrl(searchUrl(text));
            return;
        }
        askAi(text, id, key, folder);
    }

    // ---------- Вопрос к Алисе (в фоновом потоке) ----------
    private static class AiResult {
        final int code;
        final String text;
        AiResult(int code, String text) {
            this.code = code;
            this.text = text;
        }
    }

    // Один запрос к сервису Яндекса
    private AiResult postAi(JSONObject body, String key, String folder) throws Exception {
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(AI_API_URL).openConnection();
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(60000);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Authorization", "Api-Key " + key);
            conn.setRequestProperty("OpenAI-Project", folder);
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setDoOutput(true);
            try (OutputStream os = conn.getOutputStream()) {
                os.write(body.toString().getBytes(StandardCharsets.UTF_8));
            }
            int code = conn.getResponseCode();
            boolean ok = code >= 200 && code < 300;
            String text = readAll(ok ? conn.getInputStream() : conn.getErrorStream());
            return new AiResult(code, text);
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private void askAi(final String query, final int id, final String key, final String folder) {
        new Thread(() -> {
            String answer = "";
            String error = "";
            try {
                String model = "gpt://" + folder + "/" + AI_MODEL;
                JSONObject full = new JSONObject();
                full.put("model", model);
                full.put("temperature", 0.3);
                full.put("max_output_tokens", 1500);
                full.put("input", AI_PROMPT + query);

                AiResult r = postAi(full, key, folder);
                if (r.code == 400) {
                    // Пробуем ещё раз с самым простым запросом, без дополнительных параметров
                    JSONObject simple = new JSONObject();
                    simple.put("model", model);
                    simple.put("input", AI_PROMPT + query);
                    r = postAi(simple, key, folder);
                }
                if (r.code >= 200 && r.code < 300) {
                    answer = extractAnswer(new JSONObject(r.text));
                    if (answer.isEmpty()) error = "Алиса вернула пустой ответ.";
                } else {
                    error = describeError(r.code, r.text);
                }
            } catch (Exception ex) {
                error = "Нет связи с сервисом (" + ex.getClass().getSimpleName() + "). Проверьте интернет.";
            }
            final String a = answer;
            final String e = error;
            runOnUiThread(() -> {
                if (id != aiRequestId) return; // уже задан другой вопрос
                aiAnswer = a;
                aiError = e;
                aiDone = true;
                pushAnswer();
            });
        }).start();
    }

    // Кнопка "Проверить" в настройках: показывает, что именно ответил сервис
    private void testAi() {
        SharedPreferences prefs = getSharedPreferences("aura", MODE_PRIVATE);
        final String key = prefs.getString("ai_key", "");
        final String folder = prefs.getString("ai_folder", "");
        if (key.isEmpty() || folder.isEmpty()) {
            toast("Сначала введите ключ и идентификатор каталога");
            return;
        }
        toast("Проверяю подключение…");
        new Thread(() -> {
            String report = "";
            try {
                JSONObject body = new JSONObject();
                body.put("model", "gpt://" + folder + "/" + AI_MODEL);
                body.put("input", "Ответь одним словом: привет");
                AiResult r = postAi(body, key, folder);
                if (r.code >= 200 && r.code < 300) {
                    report = "Всё работает!\n\nАлиса ответила: " + extractAnswer(new JSONObject(r.text));
                } else {
                    String raw = r.text == null ? "" : r.text.trim();
                    if (raw.length() > 700) raw = raw.substring(0, 700);
                    report = "Код ответа: " + r.code + "\nИдентификатор каталога: " + folder + "\n\n" + raw;
                }
            } catch (Exception ex) {
                report = "Не удалось подключиться: " + ex.getClass().getSimpleName() + " " + ex.getMessage();
            }
            final String shown = report;
            runOnUiThread(() -> new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                    .setTitle("Проверка Алисы")
                    .setMessage(shown)
                    .setPositiveButton("OK", null)
                    .show());
        }).start();
    }

    private String readAll(InputStream in) throws java.io.IOException {
        if (in == null) return "";
        StringBuilder sb = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) sb.append(line).append('\n');
        }
        return sb.toString();
    }

    // Достаём текст ответа из ответа сервиса
    private String extractAnswer(JSONObject root) {
        StringBuilder sb = new StringBuilder();
        JSONArray output = root.optJSONArray("output");
        if (output != null) {
            for (int i = 0; i < output.length(); i++) {
                JSONObject item = output.optJSONObject(i);
                if (item == null) continue;
                JSONArray content = item.optJSONArray("content");
                if (content == null) continue;
                for (int j = 0; j < content.length(); j++) {
                    JSONObject c = content.optJSONObject(j);
                    if (c == null) continue;
                    String type = c.optString("type", "");
                    if (type.isEmpty() || "output_text".equals(type)) sb.append(c.optString("text", ""));
                }
            }
        }
        if (sb.length() == 0) sb.append(root.optString("output_text", ""));
        return sb.toString().trim();
    }

    private String describeError(int code, String body) {
        String hint;
        if (code == 400) {
            hint = "Сервис не принял запрос. Чаще всего неверный идентификатор каталога "
                    + "(нужен вид b1g…, а не название «default»).";
        } else if (code == 401 || code == 403) {
            hint = "Ключ не подошёл или у него нет прав. Проверьте ключ и идентификатор каталога.";
        } else if (code == 402) {
            hint = "Не хватает средств на платёжном аккаунте.";
        } else if (code == 404) {
            hint = "Не найден адрес сервиса или модель.";
        } else if (code == 429) {
            hint = "Слишком много запросов. Подождите немного.";
        } else {
            hint = "Сервис ответил ошибкой.";
        }
        String raw = body == null ? "" : body.trim().replaceAll("\\s+", " ");
        if (raw.length() > 300) raw = raw.substring(0, 300);
        return hint + " (код " + code + ")" + (raw.isEmpty() ? "" : "\n\n" + raw);
    }

    // Отправляем готовый ответ на страницу Aura (только если она сейчас открыта)
    private void pushAnswer() {
        String url = web.getUrl();
        if (url == null || !url.startsWith(SEARCH_PAGE)) return;
        int pageId = pageRequestId(url);
        String js;
        if (pageId == aiRequestId) {
            if (!aiDone) return; // ответ ещё в пути
            js = buildAnswerJs(pageId, aiAnswer, aiError);
        } else {
            js = buildAnswerJs(pageId, "", "Этот ответ не сохранился. Нажмите «Искать в…», чтобы продолжить.");
        }
        web.evaluateJavascript(js, null);
    }

    private int pageRequestId(String url) {
        try {
            String fragment = Uri.parse(url).getFragment();
            if (fragment == null) return -1;
            return new JSONObject(fragment).optInt("id", -1);
        } catch (JSONException ex) {
            return -1;
        }
    }

    private String buildAnswerJs(int id, String answer, String error) {
        return "(function(){var a=" + id + ",t=" + JSONObject.quote(answer) + ",e=" + JSONObject.quote(error)
                + ";if(window.auraAnswer){window.auraAnswer(a,t,e);}else{window.__auraBuf=[a,t,e];}})();";
    }

    // ---------- Настройка Алисы ----------
    private void showAiSettings() {
        final SharedPreferences prefs = getSharedPreferences("aura", MODE_PRIVATE);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);

        final EditText keyField = new EditText(this);
        keyField.setSingleLine(true);
        keyField.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        keyField.setHint(prefs.getString("ai_key", "").isEmpty()
                ? "API-ключ (секретная часть)"
                : "Ключ сохранён. Вставьте новый, чтобы заменить");

        final EditText folderField = new EditText(this);
        folderField.setSingleLine(true);
        folderField.setHint("Идентификатор каталога (folder ID)");
        folderField.setText(prefs.getString("ai_folder", ""));

        box.addView(keyField, new LinearLayout.LayoutParams(MATCH, WRAP));
        box.addView(folderField, new LinearLayout.LayoutParams(MATCH, WRAP));

        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("Подключить Алису")
                .setView(box)
                .setPositiveButton("Сохранить", (dialog, which) -> {
                    SharedPreferences.Editor editor = prefs.edit();
                    String k = keyField.getText().toString().trim();
                    if (!k.isEmpty()) editor.putString("ai_key", k);
                    editor.putString("ai_folder", folderField.getText().toString().trim());
                    editor.apply();
                    toast("Сохранено");
                })
                .setNeutralButton("Проверить", (dialog, which) -> {
                    SharedPreferences.Editor editor = prefs.edit();
                    String k = keyField.getText().toString().trim();
                    if (!k.isEmpty()) editor.putString("ai_key", k);
                    editor.putString("ai_folder", folderField.getText().toString().trim());
                    editor.apply();
                    testAi();
                })
                .setNegativeButton("Отмена", null)
                .show();
    }

    private void setEngine(int index) {
        engine = index;
        getSharedPreferences("aura", MODE_PRIVATE).edit().putInt("engine", index).apply();
        refreshEngineUI();
    }

    private void refreshEngineUI() {
        for (int i = 0; i < engineChips.length; i++) {
            if (engineChips[i] == null) continue;
            boolean on = (i == engine);
            engineChips[i].setBackground(on
                    ? rounded(ACCENT, 0, 18)
                    : rounded(0xFF1B1D2B, 0xFF3A3C50, 18));
            engineChips[i].setTextColor(on ? Color.WHITE : 0xFFC9CDE0);
        }
        if (input != null) input.setHint("Поиск в " + ENGINE_NAMES[engine]);
    }

    // ---------- Страница ----------
    private void setupWebView() {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        // Убираем из User-Agent пометку WebView, чтобы сайты считали нас обычным браузером
        s.setUserAgentString(s.getUserAgentString().replace("; wv", "").replace("Version/4.0 ", ""));
        s.setDomStorageEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if ("http".equals(scheme) || "https".equals(scheme)) {
                    return false;
                }
                if (uri.toString().startsWith(ASSET_PREFIX)) {
                    return false; // наша стартовая страница
                }
                if ("aura".equals(scheme)) {
                    if ("search".equals(uri.getHost())) {
                        // плитки на стартовой странице и кнопки на странице Aura
                        String q = uri.getQueryParameter("q");
                        String e = uri.getQueryParameter("e");
                        if (e != null) {
                            try {
                                int i = Integer.parseInt(e);
                                if (i >= 0 && i < ENGINE_NAMES.length) setEngine(i);
                            } catch (NumberFormatException ignored) { }
                        }
                        view.loadUrl(searchUrl(q == null ? "" : q));
                    } else if ("settings".equals(uri.getHost())) {
                        showAiSettings(); // ссылка "Настроить ключ" на странице Aura
                    } else {
                        view.loadUrl(AI_URL); // плитка "AI Chat"
                    }
                    return true;
                }
                try { // mailto:, tel: и т.п. отдаём другим приложениям
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (Exception ignored) { }
                return true;
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                input.setText(url.startsWith(ASSET_PREFIX) ? "" : url);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if (url != null && url.startsWith(SEARCH_PAGE)) pushAnswer();
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progress.setProgress(newProgress);
                progress.setVisibility(newProgress < 100 ? View.VISIBLE : View.INVISIBLE);
            }
        });

        web.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            try {
                String name = URLUtil.guessFileName(url, contentDisposition, mimeType);
                DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
                req.setMimeType(mimeType);
                req.addRequestHeader("User-Agent", userAgent);
                String cookie = CookieManager.getInstance().getCookie(url);
                if (cookie != null) req.addRequestHeader("Cookie", cookie);
                req.setTitle(name);
                req.setNotificationVisibility(
                        DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
                ((DownloadManager) getSystemService(DOWNLOAD_SERVICE)).enqueue(req);
                toast("Скачивание: " + name);
            } catch (Exception e) {
                toast("Не удалось скачать файл");
            }
        });
    }

    // ---------- Звезда: меню и избранное ----------
    private void showMenu() {
        final List<String[]> favs = loadFavs();
        List<String> labels = new ArrayList<>();
        labels.add("＋ Добавить эту страницу в избранное");
        labels.add("↻ Обновить страницу");
        labels.add("🗑 Очистить избранное");
        labels.add(aiMode ? "☑ Ответ Алисы над поиском: вкл" : "☐ Ответ Алисы над поиском: выкл");
        labels.add("🔑 Подключить Алису (ключ)");
        for (String[] f : favs) labels.add("★ " + f[0]);

        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("Aura browser")
                .setItems(labels.toArray(new String[0]), (dialog, which) -> {
                    if (which == 0) {
                        addFav(favs);
                    } else if (which == 1) {
                        web.reload();
                    } else if (which == 2) {
                        saveFavs(new ArrayList<String[]>());
                        toast("Избранное очищено");
                    } else if (which == 3) {
                        aiMode = !aiMode;
                        getSharedPreferences("aura", MODE_PRIVATE).edit().putBoolean("ai_on", aiMode).apply();
                        toast(aiMode ? "Ответ Алисы включён" : "Ответ Алисы выключен");
                    } else if (which == 4) {
                        showAiSettings();
                    } else {
                        web.loadUrl(favs.get(which - 5)[1]);
                    }
                })
                .show();
    }

    private void addFav(List<String[]> favs) {
        String url = web.getUrl();
        if (url == null || url.startsWith(ASSET_PREFIX)) {
            toast("Сначала откройте сайт");
            return;
        }
        String title = web.getTitle();
        if (title == null || title.trim().isEmpty()) title = url;
        title = title.replace('\t', ' ').replace('\n', ' ').trim();
        for (String[] f : favs) {
            if (f[1].equals(url)) {
                toast("Уже в избранном");
                return;
            }
        }
        favs.add(new String[]{title, url});
        saveFavs(favs);
        toast("Добавлено в избранное ★");
    }

    private List<String[]> loadFavs() {
        List<String[]> list = new ArrayList<>();
        String raw = getSharedPreferences("aura", MODE_PRIVATE).getString("favs", "");
        for (String line : raw.split("\n")) {
            String[] parts = line.split("\t", 2);
            if (parts.length == 2 && !parts[1].isEmpty()) list.add(parts);
        }
        return list;
    }

    private void saveFavs(List<String[]> list) {
        StringBuilder sb = new StringBuilder();
        for (String[] f : list) sb.append(f[0]).append('\t').append(f[1]).append('\n');
        getSharedPreferences("aura", MODE_PRIVATE).edit().putString("favs", sb.toString()).apply();
    }

    // ---------- Мелочи ----------
    private GradientDrawable rounded(int fill, int stroke, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radiusDp));
        if (stroke != 0) d.setStroke(dp(1), stroke);
        return d;
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
    }
}
