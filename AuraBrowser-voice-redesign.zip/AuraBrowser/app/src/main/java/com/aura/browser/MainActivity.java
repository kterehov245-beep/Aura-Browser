package com.aura.browser;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.speech.tts.TextToSpeech;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.RecognitionListener;
import android.os.Build;
import android.content.pm.PackageManager;
import android.Manifest;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicInteger;

public class MainActivity extends Activity {

    private static final int VOICE_PERMISSION_REQUEST = 7413;
    private SpeechRecognizer voiceRecognizer;
    private Dialog voiceDialog;
    private TextView voiceStatus;
    private boolean voiceResultReceived = false;

    // =====================================================================
    //  НАСТРОЙКИ В КОДЕ (то, что можно поменять прямо здесь)
    // =====================================================================

    // Поисковики: название и начало адреса (в конец добавляется запрос).
    // Сейчас только Bing. Чтобы вернуть выбор из нескольких, добавьте строки в оба списка,
    // например: "Google" и "https://www.google.com/search?q="
    private static final String[] ENGINE_NAMES = {"Bing"};
    private static final String[] ENGINE_URLS = {
            "https://www.bing.com/search?q="
    };

    // Чат с нейросетью "Aura AI" (кнопка ✨ и плитка "AI Chat")
    private static final String CHAT_SYSTEM =
            "Тебя зовут Aura AI, ты умный помощник в браузере Aura. Отвечай понятно, дружелюбно и по делу, "
            + "на языке пользователя, без сложной разметки. Ниже диалог, продолжи его ответом ассистента.";

    // Скрипты для открытых сайтов
    private static final String PAGE_TEXT_JS =
            "(function(){var t=(document.body&&document.body.innerText)||'';return t.substring(0,9000);})()";
    private static final String NIGHT_ON_JS =
            "(function(){var s=document.getElementById('aura-night');"
            + "if(!s){s=document.createElement('style');s.id='aura-night';(document.head||document.documentElement).appendChild(s);}"
            + "s.textContent='html{filter:invert(1) hue-rotate(180deg)!important;background:#fff!important}"
            + "img,picture,video,canvas{filter:invert(1) hue-rotate(180deg)!important}';})();";
    private static final String NIGHT_OFF_JS =
            "(function(){var s=document.getElementById('aura-night');if(s){s.remove();}})();";

    // ИИ-ответы над результатами поиска (Яндекс AI Studio).
    // Ключ и идентификатор каталога вводятся в приложении: три точки -> Настройки -> ИИ-ответы.
    private static final String AI_API_URL = "https://ai.api.cloud.yandex.net/v1/responses";
    private static final String[] AI_MODELS = {"aliceai-llm", "aliceai-llm-flash"};
    private static final String AI_PROMPT =
            "Ты помощник в браузере. Ответь на запрос пользователя понятно и по делу, "
            + "на языке запроса, без вступлений. "
            + "Если это вопрос «как сделать», дай пошаговый ответ. ";
    private static final String[] AI_LENGTH_HINTS = {
            "Ответь очень кратко: 2-4 предложения. ", "", "Дай подробный структурированный ответ. "};
    private static final int[] AI_TOKENS = {800, 1500, 3000};

    // Цвета акцента
    private static final String[] ACCENT_NAMES = {"Индиго", "Фиолетовый", "Голубой", "Зелёный", "Розовый", "Оранжевый"};
    private static final int[] ACCENT_COLORS = {
            0xFF6366F1, 0xFF8B5CF6, 0xFF3B82F6, 0xFF22C55E, 0xFFEC4899, 0xFFF97316};

    // Размер текста на сайтах (проценты)
    private static final int[] ZOOMS = {85, 100, 120, 140};
    private static final String[] ZOOM_NAMES = {"Мелкий", "Обычный", "Крупный", "Очень крупный"};

    // Вкладки-пространства под шапкой
    private static final String[] SPACE_KEYS = {"home", "work", "study", "projects"};
    private static final String[] SPACE_NAMES = {"✨ Главная", "💼 Работа", "📚 Учеба", "🚀 Проекты"};

    // Простой блок рекламы: известные рекламные и следящие домены
    private static final String[] AD_HOSTS = {
            "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com",
            "adnxs.com", "adsrvr.org", "criteo.com", "criteo.net", "taboola.com", "outbrain.com",
            "pubmatic.com", "rubiconproject.com", "openx.net", "advertising.com", "scorecardresearch.com",
            "moatads.com", "amazon-adsystem.com", "yandexadexchange.net", "an.yandex.ru", "yabs.yandex.ru",
            "mc.yandex.ru", "adfox.ru", "ads.adfox.ru", "counter.yadro.ru", "top-fwz1.mail.ru"};

    private static final String DESKTOP_UA =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) "
            + "Chrome/124.0.0.0 Safari/537.36";

    // ---- Цвета ----
    private static final int BG = 0xFF0E0F14;
    private static final int TOP_BAR = 0xFF1B1B1B;

    private static final String ASSET_PREFIX = "file:///android_asset/";
    private static final String HOME_PAGE = ASSET_PREFIX + "home.html";
    private static final String SEARCH_PAGE = ASSET_PREFIX + "search.html";
    private static final String SETTINGS_PAGE = ASSET_PREFIX + "settings.html";
    private static final String CHAT_PAGE = ASSET_PREFIX + "chat.html";
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    // =====================================================================

    private SharedPreferences prefs;
    private WebView web;
    private EditText input;
    private ProgressBar progress;
    private final TextView[] chipViews = new TextView[SPACE_KEYS.length];
    private final TextView[] engineChips = new TextView[ENGINE_NAMES.length];
    private int currentSpace = 0;

    // Сохранённые настройки
    private int engine = 0;
    private int accentIndex = 0;
    private int accent = ACCENT_COLORS[0];
    private boolean aiMode = true;
    private int aiModel = 0;
    private int aiLen = 1;
    private int zoom = 100;
    private boolean desktop = false;
    private volatile boolean adBlock = true;
    private boolean block3p = false;

    private String mobileUa = "";

    // Панель инструментов над строкой поиска (когда открыт сайт)
    private boolean toolsOn = true;
    private boolean night = false;
    private HorizontalScrollView toolsScroll;
    private TextView chipBack, chipForward, chipSite, chipShield, chipNight, chipDesktop;
    private final AtomicInteger blocked = new AtomicInteger();
    private String lastFind = "";
    private TextToSpeech tts;

    // Чат с нейросетью
    private final List<String[]> chat = new ArrayList<>(); // {роль, текст}
    private String chatCtxTitle = "";
    private String chatCtxUrl = "";
    private String chatCtxText = "";
    private boolean chatBusy = false;
    private String chatError = "";
    private int chatReq = 0;

    // ИИ-ответ
    private int aiRequestId = 0;
    private boolean aiDone = false;
    private String aiAnswer = "";
    private String aiError = "";
    private boolean warnedNoKey = false;

    // Видео на весь экран
    private View customView;
    private WebChromeClient.CustomViewCallback customViewCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("aura", MODE_PRIVATE);
        loadSettings();
        loadChat();

        getWindow().setStatusBarColor(TOP_BAR);
        getWindow().setNavigationBarColor(BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgressTintList(ColorStateList.valueOf(accent));

        web = new WebView(this);
        web.setBackgroundColor(BG);
        setupWebView();

        View line = new View(this);
        line.setBackgroundColor(0xFF2A2C3A);

        root.addView(buildTopBar(), new LinearLayout.LayoutParams(MATCH, dp(56)));
        root.addView(buildChips(), new LinearLayout.LayoutParams(MATCH, WRAP));
        root.addView(line, new LinearLayout.LayoutParams(MATCH, dp(1)));
        root.addView(progress, new LinearLayout.LayoutParams(MATCH, dp(3)));
        root.addView(web, new LinearLayout.LayoutParams(MATCH, 0, 1f));
        root.addView(buildSearchBar(), new LinearLayout.LayoutParams(MATCH, WRAP));
        setContentView(root);

        Uri data = getIntent().getData();
        if (data != null) {
            web.loadUrl(data.toString()); // ссылка из другого приложения
        } else {
            openSpace(0);
        }
    }

    // =====================================================================
    //  Сохранённые настройки
    // =====================================================================

    private int clamp(int value, int size) {
        return (value < 0 || value >= size) ? 0 : value;
    }

    private boolean isZoom(int percent) {
        for (int z : ZOOMS) if (z == percent) return true;
        return false;
    }

    private void loadSettings() {
        engine = clamp(prefs.getInt("engine", 0), ENGINE_NAMES.length);
        accentIndex = clamp(prefs.getInt("accent", 0), ACCENT_COLORS.length);
        accent = ACCENT_COLORS[accentIndex];
        aiMode = prefs.getBoolean("ai_on", true);
        aiModel = clamp(prefs.getInt("ai_model", 0), AI_MODELS.length);
        int len = prefs.getInt("ai_len", 1);
        aiLen = (len < 0 || len >= AI_TOKENS.length) ? 1 : len;
        int z = prefs.getInt("zoom", 100);
        zoom = isZoom(z) ? z : 100;
        desktop = prefs.getBoolean("desktop", false);
        adBlock = prefs.getBoolean("adblock", true);
        block3p = prefs.getBoolean("block3p", false);
        toolsOn = prefs.getBoolean("tools", true);
        night = prefs.getBoolean("night", false);
    }

    private String hex(int color) {
        return String.format(Locale.US, "#%06x", color & 0xFFFFFF);
    }

    // Применяем цвет акцента к окну и к открытой странице Aura
    private void applyAccent() {
        if (progress != null) progress.setProgressTintList(ColorStateList.valueOf(accent));
        selectSpace(currentSpace);
        refreshEngineUI();
        updateToolStates();
        injectAccent();
    }

    private void injectAccent() {
        if (web == null) return;
        String url = web.getUrl();
        if (url == null || !url.startsWith(ASSET_PREFIX)) return;
        web.evaluateJavascript(
                "document.documentElement.style.setProperty('--accent','" + hex(accent) + "');", null);
    }

    // =====================================================================
    //  Верхняя панель, вкладки, строка поиска
    // =====================================================================

    private View buildTopBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        bar.setBackgroundColor(TOP_BAR);
        bar.setPadding(dp(16), 0, dp(8), 0);

        // Кнопка меню: три вертикальные точки
        LinearLayout dots = new LinearLayout(this);
        dots.setOrientation(LinearLayout.VERTICAL);
        dots.setGravity(Gravity.CENTER);
        dots.setPadding(dp(14), 0, dp(14), 0);
        for (int i = 0; i < 3; i++) {
            View dot = new View(this);
            GradientDrawable shape = new GradientDrawable();
            shape.setShape(GradientDrawable.OVAL);
            shape.setColor(0xFFE3E6F3);
            dot.setBackground(shape);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(5), dp(5));
            lp.setMargins(0, dp(2), 0, dp(2));
            dots.addView(dot, lp);
        }
        dots.setOnClickListener(v -> showMenu());
        bar.addView(dots, new LinearLayout.LayoutParams(WRAP, MATCH));
        return bar;
    }

    private View buildChips() {
        HorizontalScrollView scroll = new HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(false);
        scroll.setBackgroundColor(0xFF121420);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(dp(16), dp(12), dp(6), dp(12));

        for (int i = 0; i < SPACE_KEYS.length; i++) {
            final int index = i;
            TextView chip = new TextView(this);
            chip.setText(SPACE_NAMES[i]);
            chip.setTextSize(15);
            chip.setGravity(Gravity.CENTER);
            chip.setPadding(dp(18), dp(9), dp(18), dp(9));
            chip.setOnClickListener(v -> openSpace(index));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(WRAP, WRAP);
            lp.setMargins(0, 0, dp(10), 0);
            row.addView(chip, lp);
            chipViews[i] = chip;
        }
        scroll.addView(row);
        selectSpace(0);
        return scroll;
    }

    private void selectSpace(int index) {
        currentSpace = index;
        for (int i = 0; i < chipViews.length; i++) {
            if (chipViews[i] == null) continue;
            boolean on = (i == index);
            chipViews[i].setBackground(on
                    ? rounded(accent, 0, 22)
                    : rounded(0xFF1B1D2B, 0xFF3A3C50, 22));
            chipViews[i].setTextColor(on ? Color.WHITE : 0xFFC9CDE0);
        }
    }

    private void openSpace(int index) {
        selectSpace(index);
        web.loadUrl(HOME_PAGE + "#" + SPACE_KEYS[index]);
    }

    private View buildSearchBar() {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setBackgroundColor(BG);
        wrap.setPadding(dp(16), dp(10), dp(16), dp(12));

        // Панель инструментов: появляется, когда открыт сайт
        wrap.addView(buildTools(), new LinearLayout.LayoutParams(MATCH, WRAP));

        // Выбор поисковика: появляется, когда вы начинаете вводить запрос
        final HorizontalScrollView engineScroll = new HorizontalScrollView(this);
        engineScroll.setHorizontalScrollBarEnabled(false);
        engineScroll.setVisibility(View.GONE);
        LinearLayout engineRow = new LinearLayout(this);
        engineRow.setOrientation(LinearLayout.HORIZONTAL);
        engineRow.setPadding(0, 0, 0, dp(10));
        for (int i = 0; i < ENGINE_NAMES.length; i++) {
            final int index = i;
            TextView chip = new TextView(this);
            chip.setText(ENGINE_NAMES[i]);
            chip.setTextSize(13);
            chip.setGravity(Gravity.CENTER);
            chip.setPadding(dp(14), dp(7), dp(14), dp(7));
            chip.setOnClickListener(v -> setEngine(index));
            LinearLayout.LayoutParams chipLp = new LinearLayout.LayoutParams(WRAP, WRAP);
            chipLp.setMargins(0, 0, dp(8), 0);
            engineRow.addView(chip, chipLp);
            engineChips[i] = chip;
        }
        engineScroll.addView(engineRow);
        wrap.addView(engineScroll, new LinearLayout.LayoutParams(MATCH, WRAP));

        LinearLayout pill = new LinearLayout(this);
        pill.setOrientation(LinearLayout.HORIZONTAL);
        pill.setGravity(Gravity.CENTER_VERTICAL);
        pill.setBackground(rounded(0xFF15161F, 0xFF2D2F40, 26));
        pill.setPadding(dp(8), 0, dp(8), 0);

        pill.addView(icon("🏠", v -> openSpace(currentSpace)));
        pill.addView(icon("✨", v -> openChat()));

        input = new EditText(this);
        input.setBackground(null);
        input.setSingleLine(true);
        input.setTextColor(Color.WHITE);
        input.setHintTextColor(0xFF7A8096);
        input.setHint("Поиск или адрес сайта");
        input.setTextSize(16);
        input.setSelectAllOnFocus(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        input.setImeOptions(EditorInfo.IME_ACTION_GO);
        input.setOnFocusChangeListener((v, hasFocus) -> {
            engineScroll.setVisibility(hasFocus && ENGINE_NAMES.length > 1 ? View.VISIBLE : View.GONE);
            if (hasFocus) {
                toolsScroll.setVisibility(View.GONE); // освобождаем место под клавиатуру
            } else {
                updateTools(web.getUrl());
            }
        });
        input.setOnEditorActionListener((v, actionId, event) -> {
            submit();
            return true;
        });
        pill.addView(input, new LinearLayout.LayoutParams(0, MATCH, 1f));

        // Голосовой ввод работает и для поиска, и для Aura AI через общее поле ввода.
        pill.addView(icon("🎙", v -> startVoiceInput()));
        pill.addView(icon("🔍", v -> submit()));

        wrap.addView(pill, new LinearLayout.LayoutParams(MATCH, dp(52)));
        refreshEngineUI();
        return wrap;
    }

    private TextView icon(String symbol, View.OnClickListener listener) {
        TextView t = new TextView(this);
        t.setText(symbol);
        t.setTextSize(20);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(10), 0, dp(10), 0);
        t.setOnClickListener(listener);
        t.setLayoutParams(new LinearLayout.LayoutParams(WRAP, MATCH));
        return t;
    }

    private boolean onChatPage() {
        String url = web.getUrl();
        return url != null && url.startsWith(CHAT_PAGE);
    }

    // Aura Voice: собственное окно записи + приоритет распознавания прямо на устройстве.
    // Если производитель телефона не предоставляет offline-движок, используем системный
    // RecognitionService без запуска отдельного окна Google.
    private void startVoiceInput() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, VOICE_PERMISSION_REQUEST);
            return;
        }
        beginAuraVoice();
    }

    private void beginAuraVoice() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            toast("На телефоне не найден сервис распознавания речи.");
            return;
        }

        // Собственное окно Aura Voice: без стандартной серой рамки Android.
        Dialog dialog = new Dialog(this);
        FrameLayout overlay = new FrameLayout(this);
        overlay.setBackgroundColor(0xD9090C18);

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setGravity(Gravity.CENTER_HORIZONTAL);
        panel.setPadding(dp(24), dp(28), dp(24), dp(24));
        GradientDrawable panelBg = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF20233D, 0xFF111522, 0xFF17172D});
        panelBg.setCornerRadius(dp(30));
        panelBg.setStroke(dp(1), 0x665E6DCE);
        panel.setBackground(panelBg);
        panel.setElevation(dp(18));

        TextView eyebrow = new TextView(this);
        eyebrow.setText("A U R A   •   VOICE");
        eyebrow.setTextColor(0xFF9DA8FF);
        eyebrow.setTextSize(11);
        eyebrow.setLetterSpacing(.18f);
        eyebrow.setGravity(Gravity.CENTER);
        panel.addView(eyebrow, new LinearLayout.LayoutParams(MATCH, dp(24)));

        FrameLayout orbWrap = new FrameLayout(this);
        LinearLayout.LayoutParams orbLp = new LinearLayout.LayoutParams(dp(154), dp(154));
        orbLp.setMargins(0, dp(22), 0, dp(20));
        panel.addView(orbWrap, orbLp);

        View halo = new View(this);
        GradientDrawable haloBg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0x665D6BFF, 0x443CCFEA, 0x665F42C8});
        haloBg.setShape(GradientDrawable.OVAL);
        haloBg.setStroke(dp(1), 0x886F8BFF);
        halo.setBackground(haloBg);
        FrameLayout.LayoutParams haloLp = new FrameLayout.LayoutParams(MATCH, MATCH);
        orbWrap.addView(halo, haloLp);

        TextView mic = new TextView(this);
        mic.setText("🎙");
        mic.setTextSize(48);
        mic.setGravity(Gravity.CENTER);
        GradientDrawable orbBg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF657BFF, 0xFF353E91, 0xFF25AFC4});
        orbBg.setShape(GradientDrawable.OVAL);
        orbBg.setStroke(dp(2), 0x99B8D9FF);
        mic.setBackground(orbBg);
        mic.setElevation(dp(8));
        FrameLayout.LayoutParams micLp = new FrameLayout.LayoutParams(dp(112), dp(112), Gravity.CENTER);
        orbWrap.addView(mic, micLp);

        TextView title = new TextView(this);
        title.setText("Aura Voice");
        title.setTextColor(Color.WHITE);
        title.setTextSize(25);
        title.setTypeface(null, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        panel.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Ваш голос — ваш быстрый доступ");
        subtitle.setTextColor(0xFF9EA7C5);
        subtitle.setTextSize(13);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(MATCH, WRAP);
        subLp.setMargins(0, dp(5), 0, dp(18));
        panel.addView(subtitle, subLp);

        // Светящаяся звуковая дорожка — визуальный индикатор прослушивания.
        LinearLayout wave = new LinearLayout(this);
        wave.setGravity(Gravity.CENTER);
        wave.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams waveLp = new LinearLayout.LayoutParams(MATCH, dp(42));
        waveLp.setMargins(0, 0, 0, dp(16));
        panel.addView(wave, waveLp);
        int[] heights = {12, 22, 34, 25, 40, 24, 34, 20, 12};
        for (int h : heights) {
            View bar = new View(this);
            GradientDrawable barBg = new GradientDrawable();
            barBg.setCornerRadius(dp(8));
            barBg.setColor(0xFF71DCEB);
            bar.setBackground(barBg);
            LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(dp(4), dp(h));
            blp.setMargins(dp(4), 0, dp(4), 0);
            wave.addView(bar, blp);
            bar.animate().scaleY(1.45f).setDuration(430 + h * 12).withEndAction(() ->
                    bar.animate().scaleY(.72f).setDuration(430 + h * 9).start()).start();
        }

        voiceStatus = new TextView(this);
        voiceStatus.setText("Слушаю… Говорите по-русски");
        voiceStatus.setTextColor(0xFFE0E5FF);
        voiceStatus.setTextSize(15);
        voiceStatus.setGravity(Gravity.CENTER);
        voiceStatus.setMinHeight(dp(48));
        voiceStatus.setPadding(dp(8), dp(8), dp(8), dp(8));
        GradientDrawable statusBg = new GradientDrawable();
        statusBg.setColor(0x442D355B);
        statusBg.setCornerRadius(dp(16));
        statusBg.setStroke(dp(1), 0x445E70C7);
        voiceStatus.setBackground(statusBg);
        panel.addView(voiceStatus, new LinearLayout.LayoutParams(MATCH, WRAP));

        TextView cancel = new TextView(this);
        cancel.setText("ОТМЕНИТЬ");
        cancel.setTextColor(0xFF9DECF1);
        cancel.setTextSize(13);
        cancel.setTypeface(null, Typeface.BOLD);
        cancel.setGravity(Gravity.CENTER);
        cancel.setLetterSpacing(.12f);
        GradientDrawable cancelBg = new GradientDrawable();
        cancelBg.setColor(0x332C9FB3);
        cancelBg.setCornerRadius(dp(22));
        cancelBg.setStroke(dp(1), 0x8861C7D9);
        cancel.setBackground(cancelBg);
        LinearLayout.LayoutParams cancelLp = new LinearLayout.LayoutParams(dp(160), dp(46));
        cancelLp.setMargins(0, dp(20), 0, 0);
        panel.addView(cancel, cancelLp);
        cancel.setOnClickListener(v -> stopAuraVoice());

        FrameLayout.LayoutParams panelLp = new FrameLayout.LayoutParams(
                MATCH, WRAP, Gravity.CENTER);
        panelLp.setMargins(dp(22), dp(24), dp(22), dp(24));
        overlay.addView(panel, panelLp);
        dialog.setContentView(overlay);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);
        dialog.setOnCancelListener(d -> stopAuraVoice());
        android.view.Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawableResource(android.R.color.transparent);
            window.addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            android.view.WindowManager.LayoutParams attrs = window.getAttributes();
            attrs.width = MATCH;
            attrs.height = MATCH;
            attrs.dimAmount = 0f;
            window.setAttributes(attrs);
        }
        voiceDialog = dialog;
        dialog.show();
        if (dialog.getWindow() != null) {
            dialog.getWindow().setLayout(MATCH, MATCH);
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        }

        try {
            if (Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
                voiceRecognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(this);
            } else {
                voiceRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
            }
            voiceRecognizer.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle params) {
                    if (voiceStatus != null) voiceStatus.setText("Говорите…");
                }
                @Override public void onBeginningOfSpeech() {
                    if (voiceStatus != null) voiceStatus.setText("Распознаю вашу речь…");
                }
                @Override public void onRmsChanged(float rmsdB) { }
                @Override public void onBufferReceived(byte[] buffer) { }
                @Override public void onEndOfSpeech() {
                    if (voiceStatus != null) voiceStatus.setText("Обрабатываю голос…");
                }
                @Override public void onError(int error) {
                    if (!voiceResultReceived) {
                        if (voiceStatus != null) voiceStatus.setText("Не удалось распознать. Попробуйте ещё раз.");
                        toast("Голос не распознан. Попробуйте ещё раз.");
                    }
                    closeAuraVoice();
                }
                @Override public void onResults(Bundle results) {
                    ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (matches != null && !matches.isEmpty()) {
                        voiceResultReceived = true;
                        String recognized = matches.get(0);
                        input.setText(recognized);
                        input.setSelection(input.getText().length());
                        input.requestFocus();
                        if (voiceStatus != null) voiceStatus.setText("Готово — проверьте текст");
                    }
                    closeAuraVoice();
                }
                @Override public void onPartialResults(Bundle partialResults) {
                    ArrayList<String> matches = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (matches != null && !matches.isEmpty() && voiceStatus != null) {
                        voiceStatus.setText(matches.get(0));
                    }
                }
                @Override public void onEvent(int eventType, Bundle params) { }
            });
            voiceResultReceived = false;
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU");
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ru-RU");
            intent.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true);
            intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
            voiceRecognizer.startListening(intent);
        } catch (Exception e) {
            closeAuraVoice();
            toast("Aura Voice сейчас недоступен на этом устройстве.");
        }
    }

    private void stopAuraVoice() {
        closeAuraVoice();
    }

    private void closeAuraVoice() {
        if (voiceRecognizer != null) {
            try { voiceRecognizer.cancel(); } catch (Exception ignored) { }
            voiceRecognizer.destroy();
            voiceRecognizer = null;
        }
        if (voiceDialog != null && voiceDialog.isShowing()) voiceDialog.dismiss();
        voiceDialog = null;
        voiceStatus = null;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == VOICE_PERMISSION_REQUEST) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                beginAuraVoice();
            } else {
                toast("Для голосового ввода нужен доступ к микрофону.");
            }
        }
    }

    private void submit() {
        if (onChatPage()) {
            // На странице чата строка внизу отправляет сообщение нейросети
            if (chatBusy) {
                toast("Подождите, ответ ещё готовится");
                return;
            }
            String text = input.getText().toString().trim();
            if (!text.isEmpty()) {
                input.setText("");
                sendChat(text);
            }
            return;
        }
        go(input.getText().toString());
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(input.getWindowToken(), 0);
        input.clearFocus();
        web.requestFocus();
    }

    // =====================================================================
    //  Поиск
    // =====================================================================

    // Адрес -> открыть сайт, обычный текст -> поиск
    private void go(String raw) {
        String text = raw.trim();
        if (text.isEmpty()) return;
        if (text.startsWith("http://") || text.startsWith("https://")) {
            web.loadUrl(text);
        } else if (text.contains(".") && !text.contains(" ")) {
            web.loadUrl("https://" + text);
        } else {
            searchQuery(text);
        }
    }

    private String searchUrl(String query) {
        return ENGINE_URLS[engine] + Uri.encode(query);
    }

    // Если ИИ-ответы включены и подключены - сначала страница Aura с ответом,
    // иначе сразу выбранный поисковик
    private void searchQuery(String text) {
        String key = prefs.getString("ai_key", "");
        String folder = prefs.getString("ai_folder", "");
        if (!aiMode) {
            web.loadUrl(searchUrl(text));
            return;
        }
        if (key.isEmpty() || folder.isEmpty()) {
            if (!warnedNoKey) {
                warnedNoKey = true;
                Toast.makeText(this, "Чтобы получать ИИ-ответы, подключите ключ: ⋮ → Настройки → ИИ-ответы",
                        Toast.LENGTH_LONG).show();
            }
            web.loadUrl(searchUrl(text));
            return;
        }
        aiRequestId++;
        final int id = aiRequestId;
        aiDone = false;
        aiAnswer = "";
        aiError = "";
        try {
            JSONArray list = new JSONArray();
            for (int i = 0; i < ENGINE_NAMES.length; i++) {
                list.put(new JSONArray().put(ENGINE_NAMES[i]).put(ENGINE_URLS[i]));
            }
            JSONObject data = new JSONObject();
            data.put("q", text);
            data.put("e", engine);
            data.put("id", id);
            data.put("engines", list);
            web.loadUrl(SEARCH_PAGE + "#" + Uri.encode(data.toString()));
        } catch (JSONException ex) {
            web.loadUrl(searchUrl(text));
            return;
        }
        askAi(text, id);
    }

    private void setEngine(int index) {
        engine = index;
        prefs.edit().putInt("engine", index).apply();
        refreshEngineUI();
    }

    private void refreshEngineUI() {
        for (int i = 0; i < engineChips.length; i++) {
            if (engineChips[i] == null) continue;
            boolean on = (i == engine);
            engineChips[i].setBackground(on
                    ? rounded(accent, 0, 18)
                    : rounded(0xFF1B1D2B, 0xFF3A3C50, 18));
            engineChips[i].setTextColor(on ? Color.WHITE : 0xFFC9CDE0);
        }
        updateInputHint(web == null ? null : web.getUrl());
    }

    private void updateInputHint(String url) {
        if (input == null) return;
        if (url != null && url.startsWith(CHAT_PAGE)) {
            input.setHint(chatCtxText.isEmpty() ? "Напишите Aura AI…" : "Спросите про эту страницу…");
        } else {
            input.setHint(ENGINE_NAMES.length > 1 ? "Поиск в " + ENGINE_NAMES[engine] : "Поиск в интернете");
        }
    }

    // =====================================================================
    //  Вопрос к нейросети (в фоновом потоке)
    // =====================================================================

    private static class AiResult {
        final int code;
        final String text;
        AiResult(int code, String text) {
            this.code = code;
            this.text = text;
        }
    }

    private AiResult postAi(JSONObject body, String key, String folder) throws Exception {
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(AI_API_URL).openConnection();
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(60000);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Authorization", "Api-Key " + key);
            conn.setRequestProperty("OpenAI-Project", folder);
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setDoOutput(true);
            try (OutputStream os = conn.getOutputStream()) {
                os.write(body.toString().getBytes(StandardCharsets.UTF_8));
            }
            int code = conn.getResponseCode();
            boolean ok = code >= 200 && code < 300;
            String text = readAll(ok ? conn.getInputStream() : conn.getErrorStream());
            return new AiResult(code, text);
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private void askAi(final String query, final int id) {
        final String prompt = AI_PROMPT + AI_LENGTH_HINTS[aiLen] + "Запрос: " + query;
        final int maxTokens = AI_TOKENS[aiLen];
        new Thread(() -> {
            final AiReply r = requestAi(prompt, maxTokens);
            runOnUiThread(() -> {
                if (id != aiRequestId) return; // уже задан другой вопрос
                aiAnswer = r.text;
                aiError = r.error;
                aiDone = true;
                pushAnswer();
            });
        }).start();
    }

    private static class AiReply {
        final String text;
        final String error;
        AiReply(String text, String error) {
            this.text = text;
            this.error = error;
        }
    }

    // Общий запрос к нейросети: возвращает текст ответа или описание ошибки
    private AiReply requestAi(String prompt, int maxTokens) {
        String key = prefs.getString("ai_key", "");
        String folder = prefs.getString("ai_folder", "");
        if (key.isEmpty() || folder.isEmpty()) {
            return new AiReply("", "Подключите ИИ: ⋮ → Настройки → ИИ-ответы.");
        }
        try {
            String model = "gpt://" + folder + "/" + AI_MODELS[aiModel];
            JSONObject full = new JSONObject();
            full.put("model", model);
            full.put("temperature", 0.3);
            full.put("max_output_tokens", maxTokens);
            full.put("input", prompt);
            AiResult r = postAi(full, key, folder);
            if (r.code == 400) {
                // Ещё раз, самым простым запросом, без дополнительных параметров
                JSONObject simple = new JSONObject();
                simple.put("model", model);
                simple.put("input", prompt);
                r = postAi(simple, key, folder);
            }
            if (r.code >= 200 && r.code < 300) {
                String answer = extractAnswer(new JSONObject(r.text));
                return answer.isEmpty()
                        ? new AiReply("", "Пустой ответ. Попробуйте ещё раз.")
                        : new AiReply(answer, "");
            }
            return new AiReply("", describeError(r.code, r.text));
        } catch (Exception ex) {
            return new AiReply("", "Нет связи с сервисом (" + ex.getClass().getSimpleName() + "). Проверьте интернет.");
        }
    }

    // Кнопка "Проверить подключение" в настройках
    private void testAi() {
        final String key = prefs.getString("ai_key", "");
        final String folder = prefs.getString("ai_folder", "");
        if (key.isEmpty() || folder.isEmpty()) {
            toast("Сначала введите ключ и идентификатор каталога");
            return;
        }
        toast("Проверяю подключение…");
        new Thread(() -> {
            String report = "";
            try {
                JSONObject body = new JSONObject();
                body.put("model", "gpt://" + folder + "/" + AI_MODELS[aiModel]);
                body.put("input", "Ответь одним словом: привет");
                AiResult r = postAi(body, key, folder);
                if (r.code >= 200 && r.code < 300) {
                    report = "Всё работает!\n\nПолучен ответ: " + extractAnswer(new JSONObject(r.text));
                } else {
                    String raw = r.text == null ? "" : r.text.trim();
                    if (raw.length() > 700) raw = raw.substring(0, 700);
                    report = "Код ответа: " + r.code + "\nИдентификатор каталога: " + folder + "\n\n" + raw;
                }
            } catch (Exception ex) {
                report = "Не удалось подключиться: " + ex.getClass().getSimpleName() + " " + ex.getMessage();
            }
            final String shown = report;
            runOnUiThread(() -> new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                    .setTitle("Проверка подключения")
                    .setMessage(shown)
                    .setPositiveButton("OK", null)
                    .show());
        }).start();
    }

    private String readAll(InputStream in) throws java.io.IOException {
        if (in == null) return "";
        StringBuilder sb = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) sb.append(line).append('\n');
        }
        return sb.toString();
    }

    // Достаём текст ответа из ответа сервиса
    private String extractAnswer(JSONObject root) {
        StringBuilder sb = new StringBuilder();
        JSONArray output = root.optJSONArray("output");
        if (output != null) {
            for (int i = 0; i < output.length(); i++) {
                JSONObject item = output.optJSONObject(i);
                if (item == null) continue;
                JSONArray content = item.optJSONArray("content");
                if (content == null) continue;
                for (int j = 0; j < content.length(); j++) {
                    JSONObject c = content.optJSONObject(j);
                    if (c == null) continue;
                    String type = c.optString("type", "");
                    if (type.isEmpty() || "output_text".equals(type)) sb.append(c.optString("text", ""));
                }
            }
        }
        if (sb.length() == 0) sb.append(root.optString("output_text", ""));
        return sb.toString().trim();
    }

    private String describeError(int code, String body) {
        String hint;
        if (code == 400) {
            hint = "Сервис не принял запрос. Чаще всего неверный идентификатор каталога "
                    + "(нужен именно идентификатор, а не название «default»).";
        } else if (code == 401 || code == 403) {
            hint = "Ключ не подошёл или у него нет прав. Проверьте ключ и идентификатор каталога.";
        } else if (code == 402) {
            hint = "Не хватает средств на платёжном аккаунте.";
        } else if (code == 404) {
            hint = "Не найден адрес сервиса или модель.";
        } else if (code == 429) {
            hint = "Слишком много запросов. Подождите немного.";
        } else {
            hint = "Сервис ответил ошибкой.";
        }
        String raw = body == null ? "" : body.trim().replaceAll("\\s+", " ");
        if (raw.length() > 300) raw = raw.substring(0, 300);
        return hint + " (код " + code + ")" + (raw.isEmpty() ? "" : "\n\n" + raw);
    }

    // Отправляем готовый ответ на страницу Aura (только если она сейчас открыта)
    private void pushAnswer() {
        String url = web.getUrl();
        if (url == null || !url.startsWith(SEARCH_PAGE)) return;
        int pageId = pageRequestId(url);
        String js;
        if (pageId == aiRequestId) {
            if (!aiDone) return; // ответ ещё в пути
            js = buildAnswerJs(pageId, aiAnswer, aiError);
        } else {
            js = buildAnswerJs(pageId, "", "Этот ответ не сохранился. Нажмите «Искать в…», чтобы продолжить.");
        }
        web.evaluateJavascript(js, null);
    }

    private int pageRequestId(String url) {
        try {
            String fragment = Uri.parse(url).getFragment();
            if (fragment == null) return -1;
            return new JSONObject(fragment).optInt("id", -1);
        } catch (JSONException ex) {
            return -1;
        }
    }

    private String buildAnswerJs(int id, String answer, String error) {
        return "(function(){var a=" + id + ",t=" + JSONObject.quote(answer) + ",e=" + JSONObject.quote(error)
                + ";if(window.auraAnswer){window.auraAnswer(a,t,e);}else{window.__auraBuf=[a,t,e];}})();";
    }

    // =====================================================================
    //  Страница
    // =====================================================================

    private void applyUserAgent() {
        web.getSettings().setUserAgentString(desktop ? DESKTOP_UA : mobileUa);
    }

    private boolean isAdHost(String host) {
        for (String h : AD_HOSTS) {
            if (host.equals(h) || host.endsWith("." + h)) return true;
        }
        return false;
    }

    private void setupWebView() {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setTextZoom(zoom);

        // Убираем из User-Agent пометку WebView, чтобы сайты считали нас обычным браузером
        mobileUa = s.getUserAgentString().replace("; wv", "").replace("Version/4.0 ", "");
        applyUserAgent();

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, !block3p);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if ("http".equals(scheme) || "https".equals(scheme)) {
                    return false;
                }
                if (uri.toString().startsWith(ASSET_PREFIX)) {
                    return false; // наши страницы
                }
                if ("aura".equals(scheme)) {
                    handleAuraLink(uri);
                    return true;
                }
                try { // mailto:, tel: и т.п. отдаём другим приложениям
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (Exception ignored) { }
                return true;
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                if (adBlock) {
                    String host = request.getUrl().getHost();
                    if (host != null && isAdHost(host)) {
                        blocked.incrementAndGet();
                        return new WebResourceResponse("text/plain", "utf-8", new ByteArrayInputStream(new byte[0]));
                    }
                }
                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                view.setAlpha(0.965f);
                view.animate().alpha(1f).setDuration(260).start();
                input.setText(url.startsWith(ASSET_PREFIX) ? "" : url);
                if (!url.startsWith(ASSET_PREFIX)) blocked.set(0);
                updateInputHint(url);
                updateTools(url);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                view.animate().alpha(1f).setDuration(220).start();
                if (url == null) return;
                if (url.startsWith(SEARCH_PAGE)) pushAnswer();
                if (url.startsWith(CHAT_PAGE)) syncChat();
                if (url.startsWith(ASSET_PREFIX)) injectAccent();
                if (!url.startsWith(ASSET_PREFIX) && night) view.evaluateJavascript(NIGHT_ON_JS, null);
                updateTools(url);
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progress.setProgress(newProgress);
                if (newProgress < 100) {
                    if (progress.getVisibility() != View.VISIBLE) {
                        progress.setAlpha(0f);
                        progress.setVisibility(View.VISIBLE);
                        progress.animate().alpha(1f).setDuration(160).start();
                    }
                } else {
                    progress.animate().alpha(0f).setDuration(220).withEndAction(() -> {
                        if (progress.getProgress() >= 100) progress.setVisibility(View.INVISIBLE);
                        progress.setAlpha(1f);
                    }).start();
                }
                if (newProgress == 100) updateTools(view.getUrl());
            }

            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                if (customView != null) {
                    callback.onCustomViewHidden();
                    return;
                }
                customView = view;
                customViewCallback = callback;
                view.setBackgroundColor(Color.BLACK);
                FrameLayout decor = (FrameLayout) getWindow().getDecorView();
                decor.addView(view, new FrameLayout.LayoutParams(MATCH, MATCH));
                decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
            }

            @Override
            public void onHideCustomView() {
                exitFullscreenVideo();
            }
        });

        web.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) ->
                startDownload(url, userAgent, contentDisposition, mimeType));

        // Поиск по странице: сколько совпадений нашлось
        web.setFindListener((active, matches, done) -> {
            if (done) toast(matches == 0 ? "Ничего не найдено" : "Совпадение " + (active + 1) + " из " + matches);
        });

        // Долгое нажатие на ссылку или картинку
        web.setOnLongClickListener(v -> {
            WebView.HitTestResult hit = web.getHitTestResult();
            String extra = hit.getExtra();
            int type = hit.getType();
            if (extra == null) return false;
            if (type == WebView.HitTestResult.SRC_ANCHOR_TYPE) {
                showLinkMenu(extra, false);
                return true;
            }
            if (type == WebView.HitTestResult.IMAGE_TYPE
                    || type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE) {
                showLinkMenu(extra, true);
                return true;
            }
            return false;
        });
    }

    private void exitFullscreenVideo() {
        if (customView == null) return;
        FrameLayout decor = (FrameLayout) getWindow().getDecorView();
        decor.removeView(customView);
        customView = null;
        decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
        if (customViewCallback != null) customViewCallback.onCustomViewHidden();
        customViewCallback = null;
    }

    private void startDownload(String url, String userAgent, String contentDisposition, String mimeType) {
        try {
            String name = URLUtil.guessFileName(url, contentDisposition, mimeType);
            DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
            if (mimeType != null) req.setMimeType(mimeType);
            if (userAgent != null) req.addRequestHeader("User-Agent", userAgent);
            String cookie = CookieManager.getInstance().getCookie(url);
            if (cookie != null) req.addRequestHeader("Cookie", cookie);
            req.setTitle(name);
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
            ((DownloadManager) getSystemService(DOWNLOAD_SERVICE)).enqueue(req);
            toast("Скачивание: " + name);
        } catch (Exception ex) {
            toast("Не удалось скачать файл");
        }
    }

    // Меню по долгому нажатию на ссылку или картинку
    private void showLinkMenu(final String url, final boolean image) {
        String[] items = image
                ? new String[]{"⬇ Скачать картинку", "📋 Копировать адрес картинки", "🔗 Поделиться"}
                : new String[]{"Открыть", "📋 Копировать ссылку", "🔗 Поделиться ссылкой"};
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setItems(items, (dialog, which) -> {
                    if (which == 0) {
                        if (image) {
                            startDownload(url, web.getSettings().getUserAgentString(), null, null);
                        } else {
                            web.loadUrl(url);
                        }
                    } else if (which == 1) {
                        copyText(url);
                    } else {
                        shareText(url);
                    }
                })
                .show();
    }

    private void copyText(String text) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("Aura", text));
        toast("Скопировано");
    }

    private void shareText(String text) {
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_TEXT, text);
        startActivity(Intent.createChooser(send, "Поделиться"));
    }

    // Адрес открытого сайта (или null, если открыта служебная страница)
    private String currentSiteUrl() {
        String url = web.getUrl();
        if (url == null || url.startsWith(ASSET_PREFIX)) return null;
        return url;
    }

    // =====================================================================
    //  Звезда: меню, избранное
    // =====================================================================

    private void showMenu() {
        String[] items = {
                "⚙ Настройки",
                "＋ Добавить страницу в избранное",
                "★ Избранное",
                "↻ Обновить страницу",
                "🔗 Поделиться ссылкой",
                "📋 Копировать ссылку"
        };
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setItems(items, (dialog, which) -> {
                    switch (which) {
                        case 0:
                            openSettings();
                            break;
                        case 1:
                            addFav();
                            break;
                        case 2:
                            showFavs();
                            break;
                        case 3:
                            web.reload();
                            break;
                        case 4:
                        case 5:
                            String url = currentSiteUrl();
                            if (url == null) {
                                toast("Сначала откройте сайт");
                            } else if (which == 4) {
                                shareText(url);
                            } else {
                                copyText(url);
                            }
                            break;
                        default:
                            break;
                    }
                })
                .show();
    }

    private void addFav() {
        String url = currentSiteUrl();
        if (url == null) {
            toast("Сначала откройте сайт");
            return;
        }
        String title = web.getTitle();
        if (title == null || title.trim().isEmpty()) title = url;
        title = title.replace('\t', ' ').replace('\n', ' ').trim();
        List<String[]> favs = loadFavs();
        for (String[] f : favs) {
            if (f[1].equals(url)) {
                toast("Уже в избранном");
                return;
            }
        }
        favs.add(new String[]{title, url});
        saveFavs(favs);
        toast("Добавлено в избранное");
    }

    private void showFavs() {
        final List<String[]> favs = loadFavs();
        if (favs.isEmpty()) {
            toast("Избранное пусто. Откройте сайт и нажмите ⋮ → «Добавить страницу»");
            return;
        }
        String[] labels = new String[favs.size()];
        for (int i = 0; i < labels.length; i++) labels[i] = "★ " + favs.get(i)[0];
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("Избранное")
                .setItems(labels, (dialog, which) -> web.loadUrl(favs.get(which)[1]))
                .show();
    }

    private List<String[]> loadFavs() {
        List<String[]> list = new ArrayList<>();
        String raw = prefs.getString("favs", "");
        for (String line : raw.split("\n")) {
            String[] parts = line.split("\t", 2);
            if (parts.length == 2 && !parts[1].isEmpty()) list.add(parts);
        }
        return list;
    }

    private void saveFavs(List<String[]> list) {
        StringBuilder sb = new StringBuilder();
        for (String[] f : list) sb.append(f[0]).append('\t').append(f[1]).append('\n');
        prefs.edit().putString("favs", sb.toString()).apply();
    }

    // =====================================================================
    //  Страница настроек (assets/settings.html) и связь с ней
    // =====================================================================

    private String versionName() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception ex) {
            return "?";
        }
    }

    private String settingsJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("version", versionName());

        JSONArray accents = new JSONArray();
        for (int i = 0; i < ACCENT_COLORS.length; i++) {
            accents.put(new JSONArray().put(ACCENT_NAMES[i]).put(hex(ACCENT_COLORS[i])));
        }
        o.put("accents", accents);
        o.put("accent", accentIndex);

        JSONArray engines = new JSONArray();
        for (String n : ENGINE_NAMES) engines.put(n);
        o.put("engines", engines);
        o.put("engine", engine);

        JSONArray zooms = new JSONArray();
        for (int i = 0; i < ZOOMS.length; i++) {
            zooms.put(new JSONArray().put(ZOOMS[i]).put(ZOOM_NAMES[i]));
        }
        o.put("zooms", zooms);
        o.put("zoom", zoom);

        o.put("ai_on", aiMode);
        o.put("ai_has_key", !prefs.getString("ai_key", "").isEmpty());
        o.put("ai_folder", prefs.getString("ai_folder", ""));
        o.put("ai_model", aiModel);
        o.put("ai_len", aiLen);

        o.put("desktop", desktop);
        o.put("adblock", adBlock);
        o.put("block3p", block3p);
        o.put("tools", toolsOn);

        JSONArray favs = new JSONArray();
        for (String[] f : loadFavs()) favs.put(new JSONArray().put(f[0]).put(f[1]));
        o.put("favs", favs);
        return o.toString();
    }

    private void openSettings() {
        try {
            web.loadUrl(SETTINGS_PAGE + "#" + Uri.encode(settingsJson()));
        } catch (JSONException ex) {
            toast("Не удалось открыть настройки");
        }
    }

    // Ссылки вида aura://... из наших страниц
    private void handleAuraLink(Uri uri) {
        String host = uri.getHost();
        if ("search".equals(host)) {
            // плитки на стартовой странице и кнопки на странице Aura
            String q = uri.getQueryParameter("q");
            String e = uri.getQueryParameter("e");
            if (e != null) {
                try {
                    int i = Integer.parseInt(e);
                    if (i >= 0 && i < ENGINE_NAMES.length) setEngine(i);
                } catch (NumberFormatException ignored) { }
            }
            web.loadUrl(searchUrl(q == null ? "" : q));
        } else if ("settings".equals(host)) {
            openSettings();
        } else if ("set".equals(host)) {
            applySetting(uri.getQueryParameter("k"), uri.getQueryParameter("v"));
        } else if ("do".equals(host)) {
            doAction(uri.getQueryParameter("name"), uri.getQueryParameter("arg"));
        } else if ("chat".equals(host)) {
            handleChatCommand(uri.getQueryParameter("cmd"), uri);
        } else {
            openChat(); // плитка "AI Chat"
        }
    }

    private void saveAiCredentials(String json) {
        try {
            JSONObject o = new JSONObject(json);
            String key = o.optString("key", "").trim();
            String folder = o.optString("folder", "").trim();
            SharedPreferences.Editor ed = prefs.edit();
            if (!key.isEmpty()) ed.putString("ai_key", key);
            ed.putString("ai_folder", folder);
            ed.apply();
        } catch (JSONException ignored) { }
    }

    private void applySetting(String k, String v) {
        if (k == null || v == null) return;
        boolean on = "1".equals(v);
        int n = -1;
        try {
            n = Integer.parseInt(v);
        } catch (NumberFormatException ignored) { }
        SharedPreferences.Editor ed = prefs.edit();
        switch (k) {
            case "accent":
                if (n >= 0 && n < ACCENT_COLORS.length) {
                    accentIndex = n;
                    accent = ACCENT_COLORS[n];
                    ed.putInt("accent", n);
                    applyAccent();
                }
                break;
            case "engine":
                if (n >= 0 && n < ENGINE_NAMES.length) setEngine(n);
                break;
            case "ai_on":
                aiMode = on;
                ed.putBoolean("ai_on", on);
                break;
            case "ai_model":
                if (n >= 0 && n < AI_MODELS.length) {
                    aiModel = n;
                    ed.putInt("ai_model", n);
                }
                break;
            case "ai_len":
                if (n >= 0 && n < AI_TOKENS.length) {
                    aiLen = n;
                    ed.putInt("ai_len", n);
                }
                break;
            case "ai_creds":
                saveAiCredentials(v);
                toast("Сохранено");
                break;
            case "zoom":
                if (isZoom(n)) {
                    zoom = n;
                    ed.putInt("zoom", n);
                    web.getSettings().setTextZoom(n);
                }
                break;
            case "desktop":
                desktop = on;
                ed.putBoolean("desktop", on);
                applyUserAgent();
                if (currentSiteUrl() != null) web.reload();
                break;
            case "adblock":
                adBlock = on;
                ed.putBoolean("adblock", on);
                break;
            case "block3p":
                block3p = on;
                ed.putBoolean("block3p", on);
                CookieManager.getInstance().setAcceptThirdPartyCookies(web, !on);
                break;
            case "tools":
                toolsOn = on;
                ed.putBoolean("tools", on);
                updateTools(web.getUrl());
                break;
            default:
                break;
        }
        ed.apply();
    }

    private void doAction(String name, String arg) {
        if (name == null) return;
        switch (name) {
            case "test_ai":
                if (arg != null && !arg.isEmpty()) saveAiCredentials(arg);
                testAi();
                break;
            case "clear_cookies":
                CookieManager.getInstance().removeAllCookies(null);
                CookieManager.getInstance().flush();
                toast("Cookie удалены");
                break;
            case "clear_cache":
                web.clearCache(true);
                WebStorage.getInstance().deleteAllData();
                web.clearHistory();
                toast("Кеш, данные сайтов и история очищены");
                break;
            case "fav_delete":
                deleteFav(arg);
                break;
            case "fav_clear":
                saveFavs(new ArrayList<String[]>());
                toast("Избранное очищено");
                break;
            case "chat_clear":
                clearChat();
                toast("История чата очищена");
                break;
            case "reset":
                resetSettings();
                break;
            default:
                break;
        }
    }

    private void deleteFav(String url) {
        if (url == null) return;
        List<String[]> favs = loadFavs();
        for (int i = 0; i < favs.size(); i++) {
            if (favs.get(i)[1].equals(url)) {
                favs.remove(i);
                break;
            }
        }
        saveFavs(favs);
    }

    private void resetSettings() {
        prefs.edit().remove("engine").remove("accent").remove("ai_on").remove("ai_model")
                .remove("ai_len").remove("zoom").remove("desktop").remove("adblock")
                .remove("block3p").remove("tools").remove("night").apply();
        loadSettings();
        web.getSettings().setTextZoom(zoom);
        applyUserAgent();
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, !block3p);
        applyAccent();
        toast("Настройки сброшены");
        openSettings();
    }

    // =====================================================================
    //  Панель инструментов над строкой поиска (когда открыт сайт)
    // =====================================================================

    private TextView toolChip(String label, View.OnClickListener listener) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextSize(13);
        t.setGravity(Gravity.CENTER);
        t.setTextColor(0xFFC9CDE0);
        t.setPadding(dp(13), dp(7), dp(13), dp(7));
        t.setBackground(rounded(0xFF1B1D2B, 0xFF3A3C50, 18));
        t.setOnClickListener(listener);
        return t;
    }

    private View buildTools() {
        toolsScroll = new HorizontalScrollView(this);
        toolsScroll.setHorizontalScrollBarEnabled(false);
        toolsScroll.setVisibility(View.GONE);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, 0, 0, dp(10));

        chipBack = toolChip("←", v -> {
            if (web.canGoBack()) web.goBack();
        });
        chipForward = toolChip("→", v -> {
            if (web.canGoForward()) web.goForward();
        });
        chipSite = toolChip("🔒", v -> showSiteInfo());
        chipShield = toolChip("🛡 0", v -> showSiteInfo());
        chipNight = toolChip("🌙 Ночь", v -> toggleNight());
        chipDesktop = toolChip("🖥 ПК", v -> toggleDesktop());

        View[] chips = {
                chipBack,
                chipForward,
                toolChip("↻", v -> web.reload()),
                chipSite,
                chipShield,
                toolChip("✨ Пересказ", v -> startPageChat(
                        "Сделай краткий пересказ этой страницы: сначала одно предложение о том, что это, "
                                + "затем главные мысли списком.")),
                toolChip("💬 Спросить", v -> startPageChat(null)),
                toolChip("🔍 Найти", v -> showFind()),
                toolChip("📖 Чтение", v -> readerMode()),
                chipNight,
                toolChip("🔊 Озвучить", v -> toggleSpeak()),
                toolChip("⭐ В избранное", v -> addFav()),
                chipDesktop,
                toolChip("Aa Текст", v -> cycleZoom()),
                toolChip("⬆ Наверх", v -> web.pageUp(true)),
                toolChip("🔗 Поделиться", v -> shareCurrent()),
                toolChip("📋 Ссылка", v -> copyCurrent())
        };
        for (View c : chips) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(WRAP, WRAP);
            lp.setMargins(0, 0, dp(8), 0);
            row.addView(c, lp);
        }
        toolsScroll.addView(row);
        updateToolStates();
        return toolsScroll;
    }

    // Показываем панель только на сайтах (не на страницах Aura и не при вводе текста)
    private void updateTools(String url) {
        if (toolsScroll == null || chipBack == null) return;
        boolean site = toolsOn && url != null && !url.startsWith(ASSET_PREFIX)
                && (input == null || !input.hasFocus());
        toolsScroll.setVisibility(site ? View.VISIBLE : View.GONE);
        if (!site) return;
        chipBack.setAlpha(web.canGoBack() ? 1f : 0.35f);
        chipForward.setAlpha(web.canGoForward() ? 1f : 0.35f);
        Uri u = Uri.parse(url);
        String host = u.getHost() == null ? "" : u.getHost().replaceFirst("^www\\.", "");
        if (host.length() > 22) host = host.substring(0, 22) + "…";
        chipSite.setText(("https".equals(u.getScheme()) ? "🔒 " : "⚠ ") + host);
        chipShield.setText("🛡 " + blocked.get());
        updateToolStates();
    }

    private void updateToolStates() {
        setActive(chipNight, night);
        setActive(chipDesktop, desktop);
    }

    private void setActive(TextView chip, boolean on) {
        if (chip == null) return;
        chip.setBackground(on ? rounded(accent, 0, 18) : rounded(0xFF1B1D2B, 0xFF3A3C50, 18));
        chip.setTextColor(on ? Color.WHITE : 0xFFC9CDE0);
    }

    private void shareCurrent() {
        String url = currentSiteUrl();
        if (url == null) toast("Сначала откройте сайт");
        else shareText(url);
    }

    private void copyCurrent() {
        String url = currentSiteUrl();
        if (url == null) toast("Сначала откройте сайт");
        else copyText(url);
    }

    private void showSiteInfo() {
        String url = currentSiteUrl();
        if (url == null) return;
        Uri u = Uri.parse(url);
        boolean https = "https".equals(u.getScheme());
        String msg = (https
                ? "🔒 Соединение защищено (HTTPS)."
                : "⚠ Соединение не защищено (HTTP). Не вводите здесь пароли и данные карт.")
                + "\n\nСайт: " + u.getHost()
                + "\n\nЗаблокировано рекламы и трекеров на этой странице: " + blocked.get()
                + (adBlock ? "" : "\n(блокировка рекламы выключена в настройках)");
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("О странице")
                .setMessage(msg)
                .setPositiveButton("OK", null)
                .show();
    }

    private void toggleNight() {
        night = !night;
        prefs.edit().putBoolean("night", night).apply();
        if (currentSiteUrl() != null) web.evaluateJavascript(night ? NIGHT_ON_JS : NIGHT_OFF_JS, null);
        updateToolStates();
        toast(night ? "Ночной режим включён" : "Ночной режим выключен");
    }

    private void toggleDesktop() {
        desktop = !desktop;
        prefs.edit().putBoolean("desktop", desktop).apply();
        applyUserAgent();
        updateToolStates();
        web.reload();
        toast(desktop ? "Версия для компьютера" : "Мобильная версия");
    }

    private void cycleZoom() {
        int idx = 0;
        for (int i = 0; i < ZOOMS.length; i++) {
            if (ZOOMS[i] == zoom) idx = i;
        }
        zoom = ZOOMS[(idx + 1) % ZOOMS.length];
        prefs.edit().putInt("zoom", zoom).apply();
        web.getSettings().setTextZoom(zoom);
        toast("Размер текста: " + zoom + "%");
    }

    private void showFind() {
        if (currentSiteUrl() == null) {
            toast("Сначала откройте сайт");
            return;
        }
        final EditText box = new EditText(this);
        box.setSingleLine(true);
        box.setHint("Что найти на странице");
        box.setText(lastFind);
        box.setSelectAllOnFocus(true);
        FrameLayout holder = new FrameLayout(this);
        holder.setPadding(dp(20), dp(8), dp(20), 0);
        holder.addView(box, new FrameLayout.LayoutParams(MATCH, WRAP));
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("Найти на странице")
                .setView(holder)
                .setPositiveButton("Найти", (d, w) -> {
                    lastFind = box.getText().toString().trim();
                    if (!lastFind.isEmpty()) web.findAllAsync(lastFind);
                })
                .setNeutralButton("Далее", (d, w) -> web.findNext(true))
                .setNegativeButton("Сбросить", (d, w) -> web.clearMatches())
                .show();
    }

    private String readAsset(String name) {
        try (InputStream in = getAssets().open(name)) {
            return readAll(in);
        } catch (Exception ex) {
            return "";
        }
    }

    // Режим чтения: оставляем на странице только статью
    private void readerMode() {
        if (currentSiteUrl() == null) {
            toast("Сначала откройте сайт");
            return;
        }
        String js = readAsset("reader.js");
        if (js.isEmpty()) {
            toast("Режим чтения недоступен");
            return;
        }
        web.evaluateJavascript(js, value -> {
            if (value != null && value.contains("no")) toast("Не удалось выделить статью на этой странице");
        });
    }

    // Результат evaluateJavascript приходит в виде JSON-строки, разворачиваем её
    private String decodeJs(String value) {
        if (value == null || "null".equals(value)) return "";
        try {
            return new JSONArray("[" + value + "]").getString(0);
        } catch (JSONException ex) {
            return "";
        }
    }

    // ---------- Озвучка страницы ----------
    private void toggleSpeak() {
        if (currentSiteUrl() == null) {
            toast("Сначала откройте сайт");
            return;
        }
        if (tts != null && tts.isSpeaking()) {
            tts.stop();
            toast("Озвучка остановлена");
            return;
        }
        web.evaluateJavascript(PAGE_TEXT_JS, value -> {
            String text = decodeJs(value).trim();
            if (text.length() < 30) {
                toast("На странице нет текста для озвучки");
                return;
            }
            speak(text);
        });
    }

    private void speak(final String text) {
        if (tts == null) {
            toast("Готовлю озвучку…");
            tts = new TextToSpeech(this, status -> {
                if (status == TextToSpeech.SUCCESS) {
                    speakNow(text);
                } else {
                    toast("Озвучка недоступна на этом телефоне");
                    tts = null;
                }
            });
        } else {
            speakNow(text);
        }
    }

    private void speakNow(String text) {
        if (tts == null) return;
        boolean cyrillic = text.matches("(?s).*[\\u0400-\\u04FF].*");
        tts.setLanguage(cyrillic ? new Locale("ru") : Locale.getDefault());
        // Озвучка принимает ограниченную длину, поэтому читаем кусками
        int pos = 0;
        int n = 0;
        while (pos < text.length()) {
            int end = Math.min(text.length(), pos + 1500);
            if (end < text.length()) {
                int cut = text.lastIndexOf('.', end);
                if (cut > pos + 300) end = cut + 1;
            }
            tts.speak(text.substring(pos, end),
                    n == 0 ? TextToSpeech.QUEUE_FLUSH : TextToSpeech.QUEUE_ADD, null, "aura" + n);
            pos = end;
            n++;
        }
        toast("Читаю страницу вслух. Нажмите «Озвучить» ещё раз, чтобы остановить");
    }

    // =====================================================================
    //  Чат с нейросетью "Aura AI" (страница assets/chat.html)
    // =====================================================================

    private void loadChat() {
        chat.clear();
        try {
            JSONArray arr = new JSONArray(prefs.getString("chat", "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONArray m = arr.getJSONArray(i);
                chat.add(new String[]{m.getString(0), m.getString(1)});
            }
        } catch (JSONException ex) {
            chat.clear();
        }
    }

    private void saveChat() {
        while (chat.size() > 40) chat.remove(0);
        JSONArray arr = new JSONArray();
        for (String[] m : chat) arr.put(new JSONArray().put(m[0]).put(m[1]));
        prefs.edit().putString("chat", arr.toString()).apply();
    }

    private String chatStateJson() throws JSONException {
        JSONObject o = new JSONObject();
        JSONArray history = new JSONArray();
        for (String[] m : chat) history.put(new JSONArray().put(m[0]).put(m[1]));
        o.put("history", history);
        o.put("busy", chatBusy);
        o.put("error", chatError);
        o.put("ctx", chatCtxText.isEmpty() ? "" : chatCtxTitle);
        return o.toString();
    }

    // Отправляем странице чата актуальное состояние (если чат сейчас открыт)
    private void syncChat() {
        String url = web.getUrl();
        if (url == null || !url.startsWith(CHAT_PAGE)) return;
        try {
            web.evaluateJavascript("window.auraChatSet&&window.auraChatSet("
                    + JSONObject.quote(chatStateJson()) + ");", null);
        } catch (JSONException ignored) { }
    }

    private void openChat() {
        web.loadUrl(CHAT_PAGE);
        syncChat();
    }

    private void sendChat(String text) {
        if (chatBusy) {
            toast("Подождите, ответ ещё готовится");
            return;
        }
        chat.add(new String[]{"user", text});
        saveChat();
        askChat();
    }

    private String buildChatPrompt() {
        StringBuilder p = new StringBuilder(CHAT_SYSTEM);
        if (!chatCtxText.isEmpty()) {
            p.append("\n\nПользователь спрашивает про страницу: ").append(chatCtxTitle)
                    .append(" (").append(chatCtxUrl).append(")\nТекст страницы:\n").append(chatCtxText);
        }
        p.append("\n\nДиалог:\n");
        for (int i = Math.max(0, chat.size() - 12); i < chat.size(); i++) {
            String[] m = chat.get(i);
            p.append("user".equals(m[0]) ? "Пользователь: " : "Aura AI: ").append(m[1]).append('\n');
        }
        p.append("Aura AI:");
        return p.toString();
    }

    private void askChat() {
        chatBusy = true;
        chatError = "";
        final int req = ++chatReq;
        syncChat();
        final String prompt = buildChatPrompt();
        new Thread(() -> {
            final AiReply r = requestAi(prompt, 2000);
            runOnUiThread(() -> {
                if (req != chatReq) return; // чат уже сброшен
                chatBusy = false;
                if (r.error.isEmpty()) {
                    chat.add(new String[]{"assistant", r.text});
                    saveChat();
                } else {
                    chatError = r.error;
                }
                syncChat();
            });
        }).start();
    }

    private void clearChat() {
        chat.clear();
        chatBusy = false;
        chatReq++;
        chatError = "";
        chatCtxTitle = "";
        chatCtxUrl = "";
        chatCtxText = "";
        saveChat();
        syncChat();
        updateInputHint(web.getUrl());
    }

    // "Пересказ" и "Спросить" на панели: чат, который знает текст открытой страницы
    private void startPageChat(final String firstMessage) {
        final String url = currentSiteUrl();
        if (url == null) {
            toast("Сначала откройте сайт");
            return;
        }
        String pageTitle = web.getTitle();
        final String title = (pageTitle == null || pageTitle.trim().isEmpty()) ? url : pageTitle.trim();
        web.evaluateJavascript(PAGE_TEXT_JS, value -> {
            String text = decodeJs(value).trim();
            if (text.length() < 80) {
                toast("На этой странице почти нет текста");
                return;
            }
            chatCtxUrl = url;
            chatCtxTitle = title;
            chatCtxText = text;
            chat.clear();
            chatBusy = false;
            chatError = "";
            chatReq++;
            if (firstMessage != null) chat.add(new String[]{"user", firstMessage});
            saveChat();
            openChat();
            if (firstMessage != null) askChat();
        });
    }

    private void handleChatCommand(String cmd, Uri uri) {
        if (cmd == null) return;
        switch (cmd) {
            case "new":
                clearChat();
                toast("Новый чат");
                break;
            case "drop_ctx":
                chatCtxTitle = "";
                chatCtxUrl = "";
                chatCtxText = "";
                syncChat();
                updateInputHint(web.getUrl());
                break;
            case "send": {
                String text = uri.getQueryParameter("text");
                if (text != null && !text.trim().isEmpty()) sendChat(text.trim());
                break;
            }
            case "copy": {
                try {
                    int i = Integer.parseInt(uri.getQueryParameter("i"));
                    if (i >= 0 && i < chat.size()) copyText(chat.get(i)[1]);
                } catch (Exception ignored) { }
                break;
            }
            default:
                break;
        }
    }

    // =====================================================================
    //  Мелочи
    // =====================================================================

    private GradientDrawable rounded(int fill, int stroke, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radiusDp));
        if (stroke != 0) d.setStroke(dp(1), stroke);
        return d;
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    public void onBackPressed() {
        if (customView != null) {
            exitFullscreenVideo();
        } else if (web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        closeAuraVoice();
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }

    @Override
    protected void onPause() {
        super.onPause();
        web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
    }
}
